# 🗓️ 家教學費與薪資自動結算工具 (Google Calendar Tutoring Calculator)

專為音樂老師、家教老師設計的**純前端月度學費明細與薪資總表自動結算網頁工具**。

只要連結 **Google 行事曆**（例如勾選「個人家教」子日曆），系統就會自動抓出指定月份每位學生有上課的日期；自行填入每位學生的鐘點費後，會即時算出**「各別學生當月費用明細」**與**「每月家教薪資總表」**，並支援一鍵匯出含公式與配色的 **Excel (`.xlsx`)** 試算表！

---

## ✨ 功能特色

1. **Google 帳號一鍵登入同步（唯讀 `calendar.readonly`）＋ `.ics` 雙軌支援**
   - 直接選擇要讀取的 Google 子日曆（如「個人家教」），自動展開每週固定週期課程（`RRULE`），並自動略過已取消或標註「請假／停課」的行程。
   - 同時支援直接匯入 Google 日曆匯出的 `.ics` 檔（免申請 API 也能離線解析）。
2. **智慧偵測新學生與關鍵字歸戶**
   - 自動去除日曆標題中的音樂符號（`🎵🎹`）與樂器字尾（如 `大提琴`、`鋼琴`、`Cello`、`Piano`），一鍵建立學生規則。
   - 支援多位名／小名關鍵字對應（例如日曆寫 `CC鋼琴` 自動歸入學生 `熹熹`）。
3. **彈性鐘點費計算（跨月自動記憶）**
   - 每位學生預設**「每堂固定金額」**，亦可切換為**「依 60 分鐘費率 × 日曆行程時長自動換算」**（例如 45m / 90m / 120m 課程）。
   - 單堂課可直接於明細表內微調金額、填寫備註、排除請假課堂，或手動新增「**書費／其他費用**」。
4. **支援「家庭／兄弟姊妹合併」雙模式**
   - **模式 A（獨立明細＋總表合併）**：給家長看的學費明細各自獨立一張（如 `燦燦` 一張、`伯寧` 一張），但在「每月家教薪資總表」自動合併為 `燦燦、伯寧` 一列加總。
   - **模式 B（同張家庭明細＋總表合併）**：明細表與薪資總表皆合併在同一張家庭帳單。
5. **分月份快速切換 ＋ 一鍵匯出 Excel (`.xlsx`)**
   - 內建零依賴 `.xlsx` 產生器：匯出的 Excel 第 1 張工作表為「**每月家教薪資收入總表**」，後續分頁為「**各學生／家庭當月費用明細**」，完整保留紫底標題、鵝黃色書費列、淺藍合計列與即時 `=SUM(...)` 及跨分頁公式！
6. **100% 隱私保護（純前端運作）**
   - 無後端資料庫，所有學生名單、鐘點費與帳務紀錄僅儲存在你個人瀏覽器的 `localStorage`，並支援 `.json` 備份匯出與還原。

---

## 🚀 部署到 GitHub Pages（免費公開給任何人使用）

本專案為**純靜態網頁（Vanilla HTML + CSS + JS，無需編譯打包）**，推上 GitHub 即可直接啟用：

1. 建立一個新的 GitHub Repository 並上傳此資料夾所有檔案：
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Google Calendar Tutoring Calculator"
   git branch -M main
   git remote add origin https://github.com/<你的帳號>/<你的專案名>.git
   git push -u origin main
   ```
2. 進入 GitHub Repo 的 **Settings → Pages**。
3. 在 **Build and deployment → Source** 選擇 `Deploy from a branch`，Branch 選擇 `main` / `/ (root)` 並按下 **Save**。
4. 等待約 1 分鐘，即可透過 `https://<你的帳號>.github.io/<你的專案名>/` 開啟使用！

---

## 🔑 設定 Google 帳號一鍵登入 (OAuth Client ID)

點擊網頁右上角的 **「⚙️ 日曆來源設定」** 內建圖文步驟說明與來源網址一鍵複製：

1. 前往 [Google Cloud Console - Google Calendar API](https://console.cloud.google.com/apis/library/calendar-json.googleapis.com) 建立專案並點擊 **「啟用 (Enable)」**。
2. 左側選單點 **「OAuth 同意畫面 (OAuth consent screen)」** → 選擇 **External (外部)** → 填寫應用程式名稱，並在 **Test users (測試使用者)** 加入要使用的 Gmail 帳號（若未來要開放不特定大眾免加名單登入，可在同頁面送出唯讀權限驗證）。
3. 左側選單點 **「憑證 (Credentials)」** → **「＋建立憑證 → OAuth 用戶端 ID」** → 類型選擇 **「網頁應用程式 (Web application)」**。
4. 在 **「已授權的 JavaScript 來源 (Authorized JavaScript origins)」** 新增你的網站根網址（不含結尾斜線與路徑），例如：
   - `https://<你的帳號>.github.io`
   - 本機測試：`http://localhost:8940`
5. 複製產生的 `xxxx.apps.googleusercontent.com`：
   - **一般使用者**：直接貼進網頁右上角「⚙️ 日曆來源設定」欄位並按登入（瀏覽器會自動記住）。
   - **Repo 擁有者**：也可直接填入 [`js/config.js`](js/config.js) 的 `DEFAULT_GOOGLE_CLIENT_ID`，之後自己打開網頁免填即可直接按一鍵登入！

---

## 💻 本機預覽執行

```bash
python3 server.py --port 8940
# 打開瀏覽器前往 http://localhost:8940
```

## 📄 授權條款

MIT License
