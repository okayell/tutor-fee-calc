/**
 * 家教學費與薪資自動結算工具 — 全域設定檔
 *
 * 【給部署到 GitHub Pages 的擁有者】
 * 如果你已經在 Google Cloud Console 建立好 OAuth 2.0 用戶端 ID (Web application)，
 * 可以直接填在下方 DEFAULT_GOOGLE_CLIENT_ID 字串中（Client ID 是公開識別碼，不含密鑰，可安全放入前端）。
 * 填好後，打開你 GitHub Pages 網址的使用者就不需要手動貼上 Client ID，直接點「Google 帳號一鍵登入」即可！
 * 若留空，使用者也可以直接在網頁右上角「⚙️ Google 同步設定」貼上自己的 Client ID（會自動記在瀏覽器本機）。
 */
window.TUTORING_CALC_CONFIG = {
  DEFAULT_GOOGLE_CLIENT_ID: '',
  CALENDAR_SCOPE: 'https://www.googleapis.com/auth/calendar.readonly',
  STORAGE_KEY: 'gcal_tutoring_calc_v1',
  DEFAULT_EXCLUDE_KEYWORDS: ['請假', '停課', '取消'],
  INSTRUMENT_SUFFIXES: [
    '大提琴課', '小提琴課', '中提琴課', '鋼琴課', '長笛課', '吉他課', '音樂課', '家教課',
    '大提琴', '小提琴', '中提琴', '鋼琴', '長笛', '吉他', '樂理', '伴奏',
    'Cello', 'cello', 'Piano', 'piano', 'Violin', 'violin',
    '小孩試上', '試上'
  ]
};
