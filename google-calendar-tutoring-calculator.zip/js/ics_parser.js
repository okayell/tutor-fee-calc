/**
 * 輔助匯入模組：支援 Google 日曆匯出之 .ics (iCalendar RFC 5545) 解析 + 互動範例資料產生器
 * 讓公開到 GitHub Pages 後，尚未申請 OAuth Client ID 的訪客也能直接匯入 .ics 或一鍵試用完整功能
 */
(function () {
  'use strict';

  const DAY_MAP = { SU: 0, MO: 1, TU: 2, WE: 3, TH: 4, FR: 5, SA: 6 };

  function format2(n) {
    return String(n).padStart(2, '0');
  }

  function parseIcsDateVal(rawVal) {
    if (!rawVal) return null;
    const clean = rawVal.trim();
    // 全天格式 YYYYMMDD
    if (/^\d{8}$/.test(clean)) {
      const y = Number(clean.slice(0, 4));
      const m = Number(clean.slice(4, 6));
      const d = Number(clean.slice(6, 8));
      return { dt: new Date(y, m - 1, d, 0, 0, 0), isAllDay: true };
    }
    // 時間格式 YYYYMMDDTHHMMSS(Z)
    const m = clean.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z)?$/);
    if (!m) return null;
    const [, yy, mm, dd, hh, mi, ss, isUtc] = m;
    if (isUtc) {
      return {
        dt: new Date(Date.UTC(Number(yy), Number(mm) - 1, Number(dd), Number(hh), Number(mi), Number(ss))),
        isAllDay: false
      };
    }
    return {
      dt: new Date(Number(yy), Number(mm) - 1, Number(dd), Number(hh), Number(mi), Number(ss)),
      isAllDay: false
    };
  }

  function unescapeIcsText(s) {
    return String(s || '')
      .replace(/\\n/gi, ' ')
      .replace(/\\,/g, ',')
      .replace(/\\;/g, ';')
      .replace(/\\\\/g, '\\')
      .trim();
  }

  function buildEventRecord(id, calName, title, startDt, durationMin, isAllDay) {
    const year = startDt.getFullYear();
    const month = startDt.getMonth() + 1;
    const day = startDt.getDate();
    const weekday = startDt.getDay();
    const dateStr = `${year}-${format2(month)}-${format2(day)}`;
    let timeLabel = '全天';
    if (!isAllDay) {
      const endDt = new Date(startDt.getTime() + durationMin * 60000);
      timeLabel = `${format2(startDt.getHours())}:${format2(startDt.getMinutes())}–${format2(endDt.getHours())}:${format2(endDt.getMinutes())}`;
    }
    return {
      id,
      rawEventId: id,
      calendarId: 'ics_import',
      calendarName: calName || '匯入的 .ics 日曆',
      title,
      dateStr,
      year,
      month,
      day,
      weekday,
      timeLabel,
      durationMin: durationMin > 0 ? durationMin : 60,
      isAllDay,
      sortTs: startDt.getTime()
    };
  }

  /**
   * 解析 .ics 文字內容，回傳展開單次與週期行程後的依月份分組 Map: { 'YYYY-MM': Event[] }
   */
  function parseIcsContent(icsText, targetYears = null) {
    // Unfold RFC 5545 multi-line fields
    const unfolded = String(icsText || '').replace(/\r\n[ \t]|\n[ \t]/g, '');
    const lines = unfolded.split(/\r?\n/);

    let calName = '匯入的日曆';
    const rawEvents = [];
    let cur = null;

    for (const line of lines) {
      if (!cur) {
        if (line.startsWith('X-WR-CALNAME:')) {
          calName = unescapeIcsText(line.slice('X-WR-CALNAME:'.length));
        } else if (line === 'BEGIN:VEVENT') {
          cur = { exdates: [] };
        }
        continue;
      }
      if (line === 'END:VEVENT') {
        rawEvents.push(cur);
        cur = null;
        continue;
      }

      const colonIdx = line.indexOf(':');
      if (colonIdx < 0) continue;
      const keyPart = line.slice(0, colonIdx);
      const valPart = line.slice(colonIdx + 1);
      const baseKey = keyPart.split(';')[0].toUpperCase();

      if (baseKey === 'UID') cur.uid = valPart.trim();
      else if (baseKey === 'SUMMARY') cur.summary = unescapeIcsText(valPart);
      else if (baseKey === 'STATUS') cur.status = valPart.trim().toUpperCase();
      else if (baseKey === 'DTSTART') cur.dtstart = parseIcsDateVal(valPart);
      else if (baseKey === 'DTEND') cur.dtend = parseIcsDateVal(valPart);
      else if (baseKey === 'RRULE') cur.rrule = valPart.trim();
      else if (baseKey === 'RECURRENCE-ID') cur.recurrenceId = parseIcsDateVal(valPart);
      else if (baseKey === 'EXDATE') {
        valPart.split(',').forEach((v) => {
          const parsed = parseIcsDateVal(v);
          if (parsed) cur.exdates.push(parsed.dt);
        });
      }
    }

    // 收集單次調課 override (UID + 原日期 YYYY-MM-DD)
    const overriddenSet = new Set();
    for (const ev of rawEvents) {
      if (ev.uid && ev.recurrenceId) {
        const d = ev.recurrenceId.dt;
        overriddenSet.add(`${ev.uid}::${d.getFullYear()}-${format2(d.getMonth() + 1)}-${format2(d.getDate())}`);
      }
    }

    const nowYear = new Date().getFullYear();
    const minYear = targetYears ? Math.min(...targetYears) : nowYear - 1;
    const maxYear = targetYears ? Math.max(...targetYears) : nowYear + 1;
    const rangeStart = new Date(minYear, 0, 1, 0, 0, 0);
    const rangeEnd = new Date(maxYear + 1, 0, 1, 0, 0, 0);

    const byMonth = {};
    const pushEv = (rec) => {
      const ym = `${rec.year}-${format2(rec.month)}`;
      if (!byMonth[ym]) byMonth[ym] = [];
      byMonth[ym].push(rec);
    };

    rawEvents.forEach((ev, idx) => {
      if (ev.status === 'CANCELLED' || !ev.dtstart || !ev.summary) return;
      const startDt = ev.dtstart.dt;
      const isAllDay = ev.dtstart.isAllDay;
      const durationMin = (ev.dtend && !isAllDay)
        ? Math.max(15, Math.round((ev.dtend.dt.getTime() - startDt.getTime()) / 60000))
        : 60;
      const uid = ev.uid || `ics_${idx}`;

      if (!ev.rrule || ev.recurrenceId) {
        if (startDt >= rangeStart && startDt < rangeEnd) {
          pushEv(buildEventRecord(`${uid}::${startDt.getTime()}`, calName, ev.summary, startDt, durationMin, isAllDay));
        }
        return;
      }

      // 解析 RRULE (支援最常見的 FREQ=WEEKLY / DAILY, INTERVAL, UNTIL, COUNT, BYDAY)
      const rules = {};
      ev.rrule.split(';').forEach((part) => {
        const [k, v] = part.split('=');
        if (k && v) rules[k.toUpperCase()] = v;
      });

      const freq = rules.FREQ || '';
      const interval = Math.max(1, Number(rules.INTERVAL) || 1);
      const untilObj = rules.UNTIL ? parseIcsDateVal(rules.UNTIL) : null;
      const untilDt = untilObj ? untilObj.dt : rangeEnd;
      const maxCount = rules.COUNT ? Number(rules.COUNT) : 2000;

      const exDateKeys = new Set(
        ev.exdates.map((d) => `${d.getFullYear()}-${format2(d.getMonth() + 1)}-${format2(d.getDate())}`)
      );

      if (freq === 'WEEKLY') {
        const byDays = rules.BYDAY
          ? rules.BYDAY.split(',').map((s) => DAY_MAP[s.slice(-2).toUpperCase()]).filter((n) => n != null)
          : [startDt.getDay()];

        // 以 startDt 所在週的週日為基準推進
        const weekZero = new Date(startDt.getFullYear(), startDt.getMonth(), startDt.getDate() - startDt.getDay());
        let count = 0;
        for (let w = 0; w < 260; w += interval) {
          let stopAll = false;
          for (const wd of byDays) {
            const occ = new Date(
              weekZero.getFullYear(),
              weekZero.getMonth(),
              weekZero.getDate() + w * 7 + wd,
              startDt.getHours(),
              startDt.getMinutes(),
              startDt.getSeconds()
            );
            if (occ < startDt) continue;
            if (occ > untilDt || occ >= rangeEnd || count >= maxCount) {
              if (occ > untilDt || occ >= rangeEnd || count >= maxCount) stopAll = true;
              continue;
            }
            count++;
            if (occ < rangeStart) continue;
            const dKey = `${occ.getFullYear()}-${format2(occ.getMonth() + 1)}-${format2(occ.getDate())}`;
            if (exDateKeys.has(dKey) || overriddenSet.has(`${uid}::${dKey}`)) continue;
            pushEv(buildEventRecord(`${uid}::${dKey}`, calName, ev.summary, occ, durationMin, isAllDay));
          }
          if (stopAll && count >= maxCount) break;
          const nextWeek = new Date(weekZero.getFullYear(), weekZero.getMonth(), weekZero.getDate() + (w + interval) * 7);
          if (nextWeek > untilDt || nextWeek >= rangeEnd) break;
        }
      }
    });

    Object.keys(byMonth).forEach((ym) => {
      byMonth[ym].sort((a, b) => a.sortTs - b.sortTs);
    });
    return { calName, byMonth };
  }

  /**
   * 建立展示用範例資料（涵蓋：一般單一學生、表情符號+樂器名、小名對應、家庭合併獨立明細 vs 家庭合併同張明細、單堂時長換算、書費）
   */
  function generateDemoDataset(year, month) {
    const monthsToGen = [
      { y: month === 1 ? year - 1 : year, m: month === 1 ? 12 : month - 1 },
      { y: year, m: month }
    ];

    const demoStudents = [
      {
        id: 'demo_s1',
        name: '東真那',
        summaryLabel: '真那',
        courseName: '大提琴課',
        keywords: ['東真那', '真那'],
        pricingMode: 'per_session',
        rate: 1000,
        groupName: '',
        groupDetailMode: 'separate_detail_merged_summary'
      },
      {
        id: 'demo_s2',
        name: '伯寧',
        summaryLabel: '',
        courseName: '大提琴課',
        keywords: ['伯寧'],
        pricingMode: 'per_session',
        rate: 950,
        groupName: '燦燦、伯寧',
        groupDetailMode: 'separate_detail_merged_summary'
      },
      {
        id: 'demo_s3',
        name: '燦燦',
        summaryLabel: '',
        courseName: '大提琴課',
        keywords: ['燦燦'],
        pricingMode: 'per_session',
        rate: 950,
        groupName: '燦燦、伯寧',
        groupDetailMode: 'separate_detail_merged_summary'
      },
      {
        id: 'demo_s4',
        name: '昱丞、昱雙',
        summaryLabel: '昱丞、昱雙',
        courseName: '鋼琴課',
        keywords: ['昱丞', '昱雙'],
        pricingMode: 'by_duration',
        rate: 800,
        groupName: '昱丞、昱雙',
        groupDetailMode: 'merged_both'
      },
      {
        id: 'demo_s5',
        name: '熹熹',
        summaryLabel: '熹熹',
        courseName: '鋼琴課',
        keywords: ['CC', '熹熹'],
        pricingMode: 'per_session',
        rate: 900,
        groupName: '',
        groupDetailMode: 'separate_detail_merged_summary'
      },
      {
        id: 'demo_s6',
        name: 'Kelly',
        summaryLabel: 'Kelly',
        courseName: '大提琴課',
        keywords: ['Kelly'],
        pricingMode: 'per_session',
        rate: 1000,
        groupName: '',
        groupDetailMode: 'separate_detail_merged_summary'
      }
    ];

    const eventsByMonth = {};
    // 每週固定課表範本: [weekday(0-6), hour, min, durationMin, title]
    const weeklySchedule = [
      [1, 17, 0, 60, '🎵伯寧大提琴'],
      [1, 19, 45, 60, '🎵燦燦大提琴'],
      [2, 13, 0, 60, 'Kelly Cello'],
      [5, 20, 0, 60, '東真那大提琴'],
      [6, 16, 0, 120, '昱丞昱雙鋼琴'],
      [6, 18, 30, 60, 'CC鋼琴']
    ];

    monthsToGen.forEach(({ y, m }) => {
      const ym = `${y}-${format2(m)}`;
      const list = [];
      const daysInMonth = new Date(y, m, 0).getDate();
      for (let d = 1; d <= daysInMonth; d++) {
        const wd = new Date(y, m - 1, d).getDay();
        weeklySchedule.forEach(([schedWd, hh, mm, dur, title], idx) => {
          if (wd === schedWd) {
            // 模擬 Kelly 隔週或偶爾請假少一堂，更貼近真實情境
            if (title === 'Kelly Cello' && d > 25) return;
            const dt = new Date(y, m - 1, d, hh, mm, 0);
            list.push(buildEventRecord(`demo_${ym}_${d}_${idx}`, '個人家教 (範例)', title, dt, dur, false));
          }
        });
      }
      eventsByMonth[ym] = list;
    });

    return { demoStudents, eventsByMonth };
  }

  window.IcsHelper = {
    parseIcsContent,
    generateDemoDataset
  };
})();
