/**
 * 純前端零依賴 OpenXML (.xlsx) 產生器
 * 支援多分頁、儲存格底色、框線、合併儲存格、欄寬、數字格式與即時 Excel 公式 (=SUM / 跨分頁參照)
 * 相容於 Microsoft Excel、Google 試算表 (Google Sheets)、macOS Numbers 與 LibreOffice Calc
 */
(function () {
  'use strict';

  // --- CRC32 表（ZIP 格式必備） ---
  const CRC_TABLE = (function () {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[i] = c >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) {
      crc = CRC_TABLE[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  // --- 建立標準 ZIP 二進位檔 (Store mode, method=0) ---
  function buildZip(files) {
    const encoder = new TextEncoder();
    const entries = files.map((f) => {
      const nameBytes = encoder.encode(f.name);
      const dataBytes = typeof f.content === 'string' ? encoder.encode(f.content) : f.content;
      return {
        nameBytes,
        dataBytes,
        crc: crc32(dataBytes),
        offset: 0
      };
    });

    let localSize = 0;
    for (const e of entries) {
      e.offset = localSize;
      localSize += 30 + e.nameBytes.length + e.dataBytes.length;
    }

    let centralSize = 0;
    for (const e of entries) {
      centralSize += 46 + e.nameBytes.length;
    }

    const totalSize = localSize + centralSize + 22;
    const out = new Uint8Array(totalSize);
    const view = new DataView(out.buffer);
    let pos = 0;

    // DOS 時間標記 (2026-01-01 00:00:00)
    const dosTime = 0x0000;
    const dosDate = ((2026 - 1980) << 9) | (1 << 5) | 1;

    for (const e of entries) {
      view.setUint32(pos, 0x04034b50, true); // Local file header signature
      view.setUint16(pos + 4, 20, true);     // Version needed to extract
      view.setUint16(pos + 6, 0x0800, true); // UTF-8 filename flag
      view.setUint16(pos + 8, 0, true);      // Compression method: 0 (stored)
      view.setUint16(pos + 10, dosTime, true);
      view.setUint16(pos + 12, dosDate, true);
      view.setUint32(pos + 14, e.crc, true);
      view.setUint32(pos + 18, e.dataBytes.length, true);
      view.setUint32(pos + 22, e.dataBytes.length, true);
      view.setUint16(pos + 26, e.nameBytes.length, true);
      view.setUint16(pos + 28, 0, true);
      pos += 30;
      out.set(e.nameBytes, pos);
      pos += e.nameBytes.length;
      out.set(e.dataBytes, pos);
      pos += e.dataBytes.length;
    }

    const centralOffset = pos;
    for (const e of entries) {
      view.setUint32(pos, 0x02014b50, true); // Central directory file header
      view.setUint16(pos + 4, 20, true);     // Version made by
      view.setUint16(pos + 6, 20, true);     // Version needed
      view.setUint16(pos + 8, 0x0800, true); // UTF-8 flag
      view.setUint16(pos + 10, 0, true);     // Compression method: 0
      view.setUint16(pos + 12, dosTime, true);
      view.setUint16(pos + 14, dosDate, true);
      view.setUint32(pos + 16, e.crc, true);
      view.setUint32(pos + 20, e.dataBytes.length, true);
      view.setUint32(pos + 24, e.dataBytes.length, true);
      view.setUint16(pos + 28, e.nameBytes.length, true);
      view.setUint16(pos + 30, 0, true);     // Extra field length
      view.setUint16(pos + 32, 0, true);     // Comment length
      view.setUint16(pos + 34, 0, true);     // Disk number
      view.setUint16(pos + 36, 0, true);     // Internal attrs
      view.setUint32(pos + 38, 0, true);     // External attrs
      view.setUint32(pos + 42, e.offset, true);
      pos += 46;
      out.set(e.nameBytes, pos);
      pos += e.nameBytes.length;
    }

    // End of central directory record
    view.setUint32(pos, 0x06054b50, true);
    view.setUint16(pos + 4, 0, true);
    view.setUint16(pos + 6, 0, true);
    view.setUint16(pos + 8, entries.length, true);
    view.setUint16(pos + 10, entries.length, true);
    view.setUint32(pos + 12, centralSize, true);
    view.setUint32(pos + 16, centralOffset, true);
    view.setUint16(pos + 20, 0, true);

    return out;
  }

  function escXml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  function colLetter(colIdx0) {
    let n = colIdx0 + 1;
    let s = '';
    while (n > 0) {
      const m = (n - 1) % 26;
      s = String.fromCharCode(65 + m) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }

  function cellRef(rowIdx0, colIdx0) {
    return colLetter(colIdx0) + (rowIdx0 + 1);
  }

  function sanitizeSheetName(rawName, usedSet) {
    let name = String(rawName || '工作表')
      .replace(/[\[\]\*\/\\\?\:]/g, '_')
      .trim();
    if (!name) name = '工作表';
    if (name.length > 28) name = name.slice(0, 28);
    let candidate = name;
    let seq = 2;
    while (usedSet.has(candidate.toLowerCase())) {
      const suffix = '_' + seq++;
      candidate = name.slice(0, 31 - suffix.length) + suffix;
    }
    usedSet.add(candidate.toLowerCase());
    return candidate;
  }

  function quoteSheetFormulaName(sheetName) {
    return "'" + String(sheetName).replace(/'/g, "''") + "'";
  }

  /**
   * 樣式索引對照 (styles.xml cellXfs):
   * 0: 一般預設
   * 1: 紫底粗體置中標題 (#DCD3EA, 框線) -> 明細表標題列
   * 2: 灰底粗體置中表頭 (#D9D9D9, 框線) -> 欄位標題 / 書費標籤
   * 3: 白底置中文字 (框線) -> 日期欄 / 序號欄
   * 4: 白底置中金額 #,##0 (框線) -> 單堂鐘點費
   * 5: 白底靠左文字 (框線) -> 備註欄 / 學生名稱
   * 6: 鵝黃底置中金額 #,##0 (#FFF2CC, 框線) -> 書費/其他費用金額
   * 7: 鵝黃底靠左文字 (#FFF2CC, 框線) -> 書費說明
   * 8: 淺藍底粗體置中標籤 (#D0E2F7, 框線) -> 明細表「合計」文字
   * 9: 淺藍底粗體置中金額 #,##0 (#D0E2F7, 框線) -> 明細表合計金額
   * 10: 暖黃底粗體置中標籤 (#FFF2CC, 框線) -> 總表「合計」文字
   * 11: 暖黃底粗體靠右金額 #,##0 (#FFF2CC, 框線) -> 總表合計金額
   * 12: 白底靠右金額 #,##0 (框線) -> 總表各學生金額
   */
  const STYLES_XML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="1">
    <numFmt numFmtId="164" formatCode="#,##0"/>
  </numFmts>
  <fonts count="3">
    <font><sz val="11"/><color rgb="FF1F2328"/><name val="Microsoft JhengHei"/></font>
    <font><b/><sz val="11"/><color rgb="FF111827"/><name val="Microsoft JhengHei"/></font>
    <font><b/><sz val="12"/><color rgb="FF111827"/><name val="Microsoft JhengHei"/></font>
  </fonts>
  <fills count="6">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFDCD3EA"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFD9D9D9"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFD0E2F7"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border>
      <left style="thin"><color rgb="FF333333"/></left>
      <right style="thin"><color rgb="FF333333"/></right>
      <top style="thin"><color rgb="FF333333"/></top>
      <bottom style="thin"><color rgb="FF333333"/></bottom>
      <diagonal/>
    </border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="13">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="164" fontId="0" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="164" fontId="1" fillId="5" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="164" fontId="1" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
  </cellXfs>
</styleSheet>`;

  function buildSheetXml(sheetDef) {
    const colsXml = (sheetDef.colWidths || [18, 16, 26]).map((w, idx) =>
      `<col min="${idx + 1}" max="${idx + 1}" width="${w}" customWidth="1"/>`
    ).join('');

    const rowsXml = sheetDef.rows.map((rowObj, rIdx) => {
      const cells = Array.isArray(rowObj) ? rowObj : rowObj.cells;
      const height = (rowObj && rowObj.height) || 24;
      const cellsXml = cells.map((c, cIdx) => {
        if (!c) return '';
        const ref = cellRef(rIdx, cIdx);
        const sAttr = c.style != null ? ` s="${c.style}"` : '';
        if (c.formula) {
          const cached = c.value != null && c.value !== '' ? `<v>${Number(c.value) || 0}</v>` : '';
          return `<c r="${ref}"${sAttr}><f>${escXml(c.formula)}</f>${cached}</c>`;
        }
        if (c.type === 'n' && c.value !== '' && c.value != null && !Number.isNaN(Number(c.value))) {
          return `<c r="${ref}"${sAttr}><v>${Number(c.value)}</v></c>`;
        }
        if (c.value === '' || c.value == null) {
          return `<c r="${ref}"${sAttr}/>`;
        }
        return `<c r="${ref}" t="inlineStr"${sAttr}><is><t>${escXml(c.value)}</t></is></c>`;
      }).join('');
      return `<row r="${rIdx + 1}" ht="${height}" customHeight="1">${cellsXml}</row>`;
    }).join('');

    const merges = sheetDef.merges || [];
    const mergeXml = merges.length > 0
      ? `<mergeCells count="${merges.length}">${merges.map((m) => `<mergeCell ref="${m}"/>`).join('')}</mergeCells>`
      : '';

    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <cols>${colsXml}</cols>
  <sheetData>${rowsXml}</sheetData>
  ${mergeXml}
</worksheet>`;
  }

  function generateWorkbookBytes(sheets) {
    const usedNames = new Set();
    const normalized = sheets.map((s) => ({
      ...s,
      safeName: sanitizeSheetName(s.name, usedNames)
    }));

    const files = [];

    files.push({
      name: '[Content_Types].xml',
      content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  ${normalized.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('\n  ')}
</Types>`
    });

    files.push({
      name: '_rels/.rels',
      content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`
    });

    files.push({
      name: 'xl/workbook.xml',
      content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    ${normalized.map((s, i) => `<sheet name="${escXml(s.safeName)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('\n    ')}
  </sheets>
</workbook>`
    });

    files.push({
      name: 'xl/_rels/workbook.xml.rels',
      content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  ${normalized.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('\n  ')}
  <Relationship Id="rId${normalized.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`
    });

    files.push({
      name: 'xl/styles.xml',
      content: STYLES_XML
    });

    normalized.forEach((s, i) => {
      files.push({
        name: `xl/worksheets/sheet${i + 1}.xml`,
        content: buildSheetXml(s)
      });
    });

    return buildZip(files);
  }

  /**
   * 將當月結算結果匯出成完整 .xlsx 檔案（含「每月家教薪資收入」總表 + 各學生／家庭費用明細分頁）
   * @param {Object} report - 由 app.js buildMonthlyReport() 計算出的結構化報表
   */
  function exportMonthlyReportToXlsx(report) {
    const { year, month, detailCards, summaryRows, grandTotal } = report;
    const ymCode = `${year}${String(month).padStart(2, '0')}`;

    // 先為每張明細卡分配唯一且合法的分頁名稱，以便總表可以直接用跨分頁公式參照！
    const tempUsed = new Set();
    const summaryTabName = sanitizeSheetName(`每月家教薪資收入_${ymCode}`, tempUsed);

    const cardSheetMeta = new Map(); // cardId -> { sheetName, totalCellRef, totalAmount }
    const detailSheets = detailCards.map((card) => {
      const sheetName = sanitizeSheetName(card.tabTitle || card.studentLabel, tempUsed);
      const isMergedMultiStudent = card.isMergedFamily && card.sessions.some((s) => s.studentName !== card.studentLabel);
      const rows = [];
      const merges = [];

      // Row 1: 標題（如：2026年11月份大提琴課費用明細）
      const colCount = isMergedMultiStudent ? 4 : 3;
      const lastCol = colLetter(colCount - 1);

      const makeTitleRow = (text) => {
        const arr = [{ value: text, style: 1 }];
        for (let i = 1; i < colCount; i++) arr.push({ value: '', style: 1 });
        return { height: 26, cells: arr };
      };

      const courseHeader = card.courseTitle
        ? `${year}年${month}月份${card.courseTitle}費用明細`
        : `${year}年${month}月份課程費用明細`;
      rows.push(makeTitleRow(courseHeader));
      merges.push(`A1:${lastCol}1`);

      // Row 2: 學生姓名
      rows.push(makeTitleRow(`學生：${card.studentLabel}`));
      merges.push(`A2:${lastCol}2`);

      // Row 3: 欄位表頭
      const rateHeader = card.rateHeaderLabel || '鐘點費/60m';
      if (isMergedMultiStudent) {
        rows.push({
          height: 24,
          cells: [
            { value: '上課日期', style: 2 },
            { value: '學生', style: 2 },
            { value: rateHeader, style: 2 },
            { value: '其他', style: 2 }
          ]
        });
      } else {
        rows.push({
          height: 24,
          cells: [
            { value: '上課日期', style: 2 },
            { value: rateHeader, style: 2 },
            { value: '其他', style: 2 }
          ]
        });
      }

      const amountColIdx = isMergedMultiStudent ? 2 : 1;
      const amountColLet = colLetter(amountColIdx);
      const firstDataRow1 = 4; // Excel 1-based row index

      // 上課日期列
      if (card.sessions.length === 0) {
        if (isMergedMultiStudent) {
          rows.push({
            height: 23,
            cells: [
              { value: '（本月無排課紀錄）', style: 3 },
              { value: '', style: 3 },
              { type: 'n', value: 0, style: 4 },
              { value: '', style: 5 }
            ]
          });
        } else {
          rows.push({
            height: 23,
            cells: [
              { value: '（本月無排課紀錄）', style: 3 },
              { type: 'n', value: 0, style: 4 },
              { value: '', style: 5 }
            ]
          });
        }
      } else {
        card.sessions.forEach((sess) => {
          if (isMergedMultiStudent) {
            rows.push({
              height: 23,
              cells: [
                { value: sess.dateShortLabel, style: 3 },
                { value: sess.studentName, style: 3 },
                { type: 'n', value: sess.amount, style: 4 },
                { value: sess.note || '', style: 5 }
              ]
            });
          } else {
            rows.push({
              height: 23,
              cells: [
                { value: sess.dateShortLabel, style: 3 },
                { type: 'n', value: sess.amount, style: 4 },
                { value: sess.note || '', style: 5 }
              ]
            });
          }
        });
      }

      // 書費 / 其他費用列（至少保留一列，與使用者截圖一致）
      const extras = card.extras && card.extras.length > 0
        ? card.extras
        : [{ label: '書費/其他費用', amount: '', note: '' }];

      extras.forEach((ex) => {
        const hasAmt = ex.amount !== '' && ex.amount != null && Number(ex.amount) !== 0;
        if (isMergedMultiStudent) {
          rows.push({
            height: 23,
            cells: [
              { value: ex.label || '書費/其他費用', style: 2 },
              { value: '', style: 2 },
              hasAmt ? { type: 'n', value: Number(ex.amount), style: 6 } : { value: '', style: 6 },
              { value: ex.note || '', style: 7 }
            ]
          });
          const r1 = rows.length;
          merges.push(`A${r1}:B${r1}`);
        } else {
          rows.push({
            height: 23,
            cells: [
              { value: ex.label || '書費/其他費用', style: 2 },
              hasAmt ? { type: 'n', value: Number(ex.amount), style: 6 } : { value: '', style: 6 },
              { value: ex.note || '', style: 7 }
            ]
          });
        }
      });

      const lastDataRow1 = rows.length; // 1-based
      const totalRow1 = lastDataRow1 + 1;
      const sumFormula = `SUM(${amountColLet}${firstDataRow1}:${amountColLet}${lastDataRow1})`;

      if (isMergedMultiStudent) {
        rows.push({
          height: 26,
          cells: [
            { value: '合計', style: 8 },
            { value: '', style: 8 },
            { formula: sumFormula, value: card.totalAmount, style: 9 },
            { value: '', style: 8 }
          ]
        });
        merges.push(`A${totalRow1}:B${totalRow1}`);
      } else {
        rows.push({
          height: 26,
          cells: [
            { value: '合計', style: 8 },
            { formula: sumFormula, value: card.totalAmount, style: 9 },
            { value: '', style: 8 }
          ]
        });
      }

      cardSheetMeta.set(card.cardId, {
        sheetName,
        totalCellRef: `${amountColLet}${totalRow1}`,
        totalAmount: card.totalAmount
      });

      return {
        name: sheetName,
        colWidths: isMergedMultiStudent ? [16, 14, 16, 26] : [18, 16, 26],
        rows,
        merges
      };
    });

    // 建立第 1 張總表：每月家教薪資收入（比照截圖 2，並用公式自動參照各明細分頁合計！）
    const summarySheetRows = [];
    const summaryMerges = [];

    summarySheetRows.push({
      height: 28,
      cells: [
        { value: `${year}年${month}月份 每月家教薪資收入總表`, style: 1 },
        { value: '', style: 1 },
        { value: '', style: 1 },
        { value: '', style: 1 },
        { value: '', style: 1 }
      ]
    });
    summaryMerges.push('A1:E1');

    summarySheetRows.push({
      height: 24,
      cells: [
        { value: '序號', style: 2 },
        { value: '學生 / 家庭', style: 2 },
        { value: '本月總額', style: 2 },
        { value: '堂數', style: 2 },
        { value: '備註 / 明細組成', style: 2 }
      ]
    });

    const firstSumRow1 = 3;
    if (summaryRows.length === 0) {
      summarySheetRows.push({
        height: 24,
        cells: [
          { type: 'n', value: 1, style: 3 },
          { value: '（尚無學生資料）', style: 3 },
          { type: 'n', value: 0, style: 12 },
          { type: 'n', value: 0, style: 3 },
          { value: '', style: 5 }
        ]
      });
    } else {
      summaryRows.forEach((sRow, idx) => {
        // 找出此總表列對應的一或多張明細分頁，自動組合跨分頁公式！
        const refs = (sRow.sourceCardIds || [])
          .map((cid) => cardSheetMeta.get(cid))
          .filter(Boolean)
          .map((m) => `${quoteSheetFormulaName(m.sheetName)}!${m.totalCellRef}`);

        const amountCell = refs.length > 0
          ? { formula: refs.join('+'), value: sRow.totalAmount, style: 12 }
          : { type: 'n', value: sRow.totalAmount, style: 12 };

        summarySheetRows.push({
          height: 24,
          cells: [
            { type: 'n', value: idx + 1, style: 3 },
            { value: sRow.label, style: 3 },
            amountCell,
            { type: 'n', value: sRow.sessionCount, style: 3 },
            { value: sRow.breakdownNote || '', style: 5 }
          ]
        });
      });
    }

    const lastSumRow1 = summarySheetRows.length;
    summarySheetRows.push({
      height: 27,
      cells: [
        { value: '', style: 10 },
        { value: '合計', style: 10 },
        { formula: `SUM(C${firstSumRow1}:C${lastSumRow1})`, value: grandTotal, style: 11 },
        { formula: `SUM(D${firstSumRow1}:D${lastSumRow1})`, value: report.totalSessions, style: 10 },
        { value: '', style: 10 }
      ]
    });

    const summarySheet = {
      name: summaryTabName,
      colWidths: [8, 22, 16, 10, 32],
      rows: summarySheetRows,
      merges: summaryMerges
    };

    const bytes = generateWorkbookBytes([summarySheet, ...detailSheets]);
    const blob = new Blob([bytes], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });

    const filename = `家教學費明細與薪資總表_${ymCode}.xlsx`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 500);
    return filename;
  }

  window.XlsxExporter = {
    generateWorkbookBytes,
    exportMonthlyReportToXlsx
  };
})();
