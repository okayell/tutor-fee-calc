/* 家教學費與薪資結算工具 — releases.js (由 tools/release_mgr.py 自動產生)
 * 版本徽章、Release Notes 歷史紀錄與本機「待發布變更偵測 / 1.x.x 智慧進位發布 & GitHub 打包下載中心」
 */
(function () {
  'use strict';

  const RELEASES_DATA = {
  "current_version": "1.0.0",
  "releases": [
    {
      "version": "1.0.0",
      "date": "2026-11-02",
      "bump": "major",
      "title": "家教學費與薪資自動結算工具 v1.0.0 初版發布",
      "highlights": [
        "🔗 支援 Google 帳號一鍵登入同步（唯讀 calendar.readonly），可勾選「個人家教」等子日曆並自動展開每週固定課程與單次請假調課；亦支援直接匯入 .ics 日曆檔。",
        "✨ 智慧偵測未歸戶行程：自動過濾音樂表情符號與樂器名稱，支援一鍵建立學生規則或將小名（如 CC）歸入現有學生。",
        "💰 彈性鐘點費與分月微調：每位學生預設「每堂固定金額」，可切換「依 60 分鐘費率 × 日曆時長自動換算」，並支援單堂微調金額、新增書費／其他費用列與手動補登課堂。",
        "👨‍👩‍👧‍👦 家庭合併雙模式：支援「各自獨立明細表、只在每月薪資總表合併加總」或「同一張家庭明細合併顯示」。",
        "📥 內建零依賴 Excel (.xlsx) 匯出器：一鍵產出「每月家教薪資收入總表」與「各學生費用明細分頁」，完整保留紫底標題、鵝黃書費列、淺藍合計列與即時 =SUM() 及跨表公式。",
        "🏷️ 標題列整合版號徽章（v1.x.x）、Release Notes 歷史紀錄與本機一鍵打包下載／發布中心。"
      ],
      "files_count": 10
    }
  ]
};
  window.TUTORING_RELEASES_DATA = RELEASES_DATA;

  const BUMP_LABELS = {
    major: { badge: 'Major 大改版', cls: 'rel-chip-bad' },
    minor: { badge: 'Minor 功能擴充', cls: 'rel-chip-info' },
    patch: { badge: 'Patch 細節修正', cls: 'rel-chip-ok' }
  };

  let cachedStatus = null;

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function isStaticEnv() {
    const host = (typeof location !== 'undefined' && location.hostname) || '';
    return !!(
      window.TUTORING_STATIC_ONLY ||
      (location.protocol !== 'http:' && location.protocol !== 'https:') ||
      /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(host)
    );
  }

  function notify(msg, type) {
    const box = document.getElementById('toastContainer');
    if (!box) return;
    const el = document.createElement('div');
    el.className = 'toast toast-' + (type || 'info');
    el.textContent = msg;
    box.appendChild(el);
    requestAnimationFrame(() => el.classList.add('visible'));
    setTimeout(() => {
      el.classList.remove('visible');
      setTimeout(() => el.remove(), 260);
    }, 3400);
  }

  function updateBadgeUI(status) {
    const btn = document.getElementById('verBadgeBtn');
    if (!btn) return;
    const ver = (status && status.current_version) || RELEASES_DATA.current_version || '1.0.0';
    const localMode = !!(status && !status.static) && !isStaticEnv();
    const hasChanges = localMode && !!(status && status.has_changes);
    btn.className = 'ver-badge' + (hasChanges ? ' has-changes' : '');
    btn.innerHTML = '<span>v' + esc(ver) + '</span>' + (hasChanges ? '<i class="ver-dot" title="有未發布的修改檔案"></i>' : '');
    if (!localMode) {
      btn.title = '版本 v' + ver + '（點擊查看 Release Notes）';
    } else {
      btn.title = hasChanges
        ? '目前版本 v' + ver + '（偵測到 ' + status.changed_files.length + ' 個檔案已修改，點擊查看 Release Notes、下載打包檔或發布新版本）'
        : '目前版本 v' + ver + '（點擊查看 Release Notes 與下載 GitHub Pages 打包檔）';
    }
  }

  async function fetchReleaseStatus() {
    if (isStaticEnv()) return null;
    try {
      const res = await fetch('api/release_status', { cache: 'no-store' });
      if (!res.ok) return null;
      const ct = (res.headers && res.headers.get && res.headers.get('content-type')) || '';
      if (!ct.includes('application/json')) return null;
      cachedStatus = await res.json();
      if (cachedStatus && cachedStatus.current_version) {
        RELEASES_DATA.current_version = cachedStatus.current_version;
        RELEASES_DATA.releases = cachedStatus.releases || RELEASES_DATA.releases;
      }
      updateBadgeUI(cachedStatus);
      return cachedStatus;
    } catch (_) {
      return null;
    }
  }

  function renderReleaseModal(status) {
    let bd = document.getElementById('relModal');
    if (!bd) {
      bd = document.createElement('div');
      bd.id = 'relModal';
      bd.className = 'modal-backdrop';
      bd.addEventListener('click', (e) => {
        if (e.target === bd) bd.classList.add('hidden');
      });
      document.body.appendChild(bd);
    }

    const ver = (status && status.current_version) || RELEASES_DATA.current_version || '1.0.0';
    const releases = (status && status.releases) || RELEASES_DATA.releases || [];
    const isLocalServer = !!(status && !status.static) && !isStaticEnv();
    const hasChanges = isLocalServer && !!(status && status.has_changes);

    let localSectionHtml = '';
    if (isLocalServer) {
      const exportBoxHtml =
        '<div class="rel-status-box">' +
          '<div class="rel-box-head">' +
            '<div>' +
              '<strong>📦 GitHub Pages 靜態版打包下載</strong>' +
              '<div class="rel-muted">一鍵下載最新單一 <code>index.html</code> 或完整開源專案 <code>.zip</code>，直接拖進 GitHub 即可上線（公開版僅顯示純淨 Release Notes）。</div>' +
            '</div>' +
            '<div class="rel-dl-btns">' +
              '<a class="btn btn-sm btn-primary" href="download/index.html" download="index.html">⬇️ 直接下載最新 index.html</a>' +
              '<a class="btn btn-sm btn-outline" href="download/zip" download="google-calendar-tutoring-calculator.zip">📦 下載完整專案包 (.zip)</a>' +
            '</div>' +
          '</div>' +
        '</div>';

      if (!hasChanges) {
        localSectionHtml = exportBoxHtml +
          '<div class="rel-status-box rel-clean">' +
            '<div>✅ 目前工作目錄所有程式碼皆與最新發布版 <strong>v' + esc(ver) + '</strong> 同步，無待發布修改。</div>' +
          '</div>';
      } else {
        const rec = status.recommended_bump || 'patch';
        const nv = status.next_versions || {};
        const filesRows = (status.changed_files || []).map((f) =>
          '<tr>' +
            '<td><span class="rel-chip rel-chip-info">' + esc(f.cat) + '</span></td>' +
            '<td><code>' + esc(f.path) + '</code><div class="rel-muted">' + esc(f.desc) + '</div></td>' +
            '<td><span class="rel-chip rel-chip-warn">' + esc(f.status_zh) + '</span></td>' +
            '<td class="nowrap"><b><span class="rel-plus">+' + f.added_lines + '</span> / <span class="rel-minus">-' + f.removed_lines + '</span> 行</b></td>' +
          '</tr>'
        ).join('');

        const descMap = {
          patch: '進第 3 位數（1.x.X）：微調樣式、文字修正、小 Bug 修復',
          minor: '進第 2 位數（1.X.0）：新增功能、計費規則或匯出體驗擴充',
          major: '進第 1 位數（X.0.0）：全站架構大改版、跨模組大規模升級'
        };

        const bumpOpts = ['patch', 'minor', 'major'].map((b) => {
          const isRec = b === rec;
          const targetVer = nv[b] || '';
          return '<label class="rel-bump-opt' + (isRec ? ' on' : '') + '">' +
            '<input type="radio" name="relBumpType" value="' + b + '"' + (isRec ? ' checked' : '') + ' />' +
            '<div class="rbo-top">' +
              '<strong>v' + esc(targetVer) + '</strong>' +
              (isRec ? '<span class="rel-chip rel-chip-ok">🤖 系統推薦</span>' : '') +
            '</div>' +
            '<div class="rbo-sub">' + esc(descMap[b]) + '</div>' +
          '</label>';
        }).join('');

        localSectionHtml = exportBoxHtml +
          '<div class="rel-status-box rel-dirty">' +
            '<div class="rel-box-head">' +
              '<div><span class="rel-chip rel-chip-warn">⚠️ 偵測到未發布變更</span> <strong>共有 ' + status.changed_files.length + ' 個檔案自 v' + esc(ver) + ' 後有修改</strong></div>' +
              '<span class="rel-muted">總變動：<b class="rel-plus">+' + status.total_added + '</b> / <b class="rel-minus">-' + status.total_removed + '</b> 行</span>' +
            '</div>' +
            '<div class="rel-ai-advice">🧭 <strong>智慧版號進位判斷（1.x.x）：</strong>' + esc(status.recommendation_reason) + '</div>' +
            '<div class="rel-diff-table-wrap">' +
              '<table class="rel-diff-table"><thead><tr><th>分類</th><th>修改檔案與說明</th><th>狀態</th><th>行數變動</th></tr></thead><tbody>' + filesRows + '</tbody></table>' +
            '</div>' +
            '<div class="rel-bump-grid">' + bumpOpts + '</div>' +
            '<div class="rel-form">' +
              '<label class="field-label">新版本標題（Release Title）</label>' +
              '<input type="text" id="relTitleInp" class="text-input" value="' + esc(status.suggested_title || '') + '" placeholder="簡述本次更新重點" />' +
              '<label class="field-label" style="margin-top:10px">更新細項（Release Notes，每行一條，已自動預填）</label>' +
              '<textarea id="relHighlightsInp" class="text-input" rows="3">' + esc((status.suggested_highlights || []).join('\n')) + '</textarea>' +
              '<div class="rel-pub-actions">' +
                '<button type="button" class="btn btn-primary" id="publishRelBtn">🚀 發布新版本 v<span id="publishVerTxt">' + esc(nv[rec] || '') + '</span> 並同步重新打包</button>' +
              '</div>' +
            '</div>' +
          '</div>';
      }
    }

    const historyHtml = releases.map((r, idx) => {
      const bInfo = BUMP_LABELS[r.bump] || BUMP_LABELS.minor;
      const items = (r.highlights || []).map((h) => '<li>' + esc(h) + '</li>').join('');
      return '<div class="rel-item' + (idx === 0 ? ' latest' : '') + '">' +
        '<div class="ri-head">' +
          '<span class="ri-ver">v' + esc(r.version) + '</span>' +
          (idx === 0 ? '<span class="rel-chip rel-chip-ok">目前版本</span>' : '') +
          '<span class="rel-chip ' + bInfo.cls + '">' + esc(bInfo.badge) + '</span>' +
          '<span class="ri-date">📅 ' + esc(r.date) + (r.files_count ? ' · 涵蓋 ' + r.files_count + ' 個檔案' : '') + '</span>' +
        '</div>' +
        '<h4 class="ri-title">' + esc(r.title) + '</h4>' +
        '<ul class="ri-list">' + items + '</ul>' +
      '</div>';
    }).join('');

    const modalTitle = isLocalServer
      ? '🚀 家教學費與薪資結算工具 · 版本紀錄與發布中心'
      : '📜 家教學費與薪資結算工具 · Release Notes';
    const modalSub = isLocalServer
      ? '<p class="field-hint">遵循語意化版本 <code>MAJOR.MINOR.PATCH (1.x.x)</code>：大改版進第 1 位、新功能擴充進第 2 位、細節微調與修正進第 3 位。</p>'
      : '';

    bd.innerHTML =
      '<div class="modal-card rel-modal-card" role="dialog" aria-modal="true" aria-label="Release Notes">' +
        '<div class="modal-header">' +
          '<div>' +
            '<div class="rel-title-row">' +
              '<h3>' + modalTitle + '</h3>' +
              '<span class="ver-pill-lg">v' + esc(ver) + '</span>' +
            '</div>' +
            modalSub +
          '</div>' +
          '<button type="button" class="modal-close" id="closeRelModalBtn" aria-label="關閉">✕</button>' +
        '</div>' +
        '<div class="modal-body">' +
          localSectionHtml +
          '<h4 class="rel-sec-title"' + (!isLocalServer ? ' style="margin-top:0"' : '') + '>📜 Release Notes 歷史版本紀錄</h4>' +
          '<div class="rel-timeline">' + historyHtml + '</div>' +
        '</div>' +
      '</div>';

    bd.classList.remove('hidden');
    bd.querySelector('#closeRelModalBtn').addEventListener('click', () => bd.classList.add('hidden'));

    bd.querySelectorAll('[name="relBumpType"]').forEach((radio) => {
      radio.addEventListener('change', () => {
        bd.querySelectorAll('.rel-bump-opt').forEach((el) => el.classList.remove('on'));
        const card = radio.closest('.rel-bump-opt');
        if (card) card.classList.add('on');
        const vTxt = bd.querySelector('#publishVerTxt');
        if (vTxt && status && status.next_versions) {
          vTxt.textContent = status.next_versions[radio.value] || '';
        }
      });
    });

    const pubBtn = bd.querySelector('#publishRelBtn');
    if (pubBtn) {
      pubBtn.addEventListener('click', async () => {
        const checked = bd.querySelector('[name="relBumpType"]:checked');
        const bumpType = checked ? checked.value : (status.recommended_bump || 'patch');
        const titleVal = (bd.querySelector('#relTitleInp') || {}).value || '';
        const hlRaw = (bd.querySelector('#relHighlightsInp') || {}).value || '';
        const highlights = hlRaw.split('\n').map((s) => s.trim()).filter(Boolean);
        pubBtn.disabled = true;
        pubBtn.textContent = '⏳ 正在發布並重新打包 index.html 與 ZIP ...';
        try {
          const res = await fetch('api/release_publish', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bump: bumpType, title: titleVal, highlights })
          });
          const out = await res.json();
          if (out && out.ok) {
            cachedStatus = out.status;
            RELEASES_DATA.current_version = out.new_version;
            RELEASES_DATA.releases = out.status.releases;
            updateBadgeUI(cachedStatus);
            renderReleaseModal(cachedStatus);
            notify('🎉 已發布 v' + out.new_version + ' 並同步更新 GitHub Pages 打包檔！', 'success');
          } else {
            pubBtn.disabled = false;
            pubBtn.textContent = '🚀 重新嘗試發布';
            notify('發布失敗：' + ((out && out.error) || '未知錯誤'), 'error');
          }
        } catch (_) {
          pubBtn.disabled = false;
          pubBtn.textContent = '🚀 重新嘗試發布';
          notify('無法連線至本機伺服器', 'error');
        }
      });
    }
  }

  async function openReleaseModal() {
    const st = await fetchReleaseStatus();
    renderReleaseModal(st || cachedStatus);
  }

  function initVersionBadge() {
    const btn = document.getElementById('verBadgeBtn');
    if (btn && !btn.dataset.bound) {
      btn.dataset.bound = '1';
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openReleaseModal();
      });
    }
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const bd = document.getElementById('relModal');
        if (bd) bd.classList.add('hidden');
      }
    });
    updateBadgeUI(cachedStatus);
    fetchReleaseStatus().then(() => {
      if (location.search.includes('releases=1') || location.hash === '#/releases') {
        openReleaseModal();
      }
    });
  }

  window.openTutoringReleaseModal = openReleaseModal;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initVersionBadge);
  } else {
    initVersionBadge();
  }
})();
