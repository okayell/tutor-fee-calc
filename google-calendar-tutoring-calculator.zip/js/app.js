/**
 * 家教學費與薪資自動結算工具 — 主程式邏輯 (app.js)
 * 負責：狀態儲存、智慧比對日曆行程與學生、單堂／時長計費、家庭合併雙模式、分月微調、UI 渲染與匯出
 */
(function () {
  'use strict';

  const CFG = window.TUTORING_CALC_CONFIG;
  const WEEKDAY_ZH = ['日', '一', '二', '三', '四', '五', '六'];

  // --- 預設初始狀態 ---
  function getDefaultState() {
    const now = new Date();
    return {
      clientId: CFG.DEFAULT_GOOGLE_CLIENT_ID || '',
      selectedCalendars: [],   // [{ id, summary }]
      cachedCalendars: [],
      activeYear: now.getFullYear(),
      activeMonth: now.getMonth() + 1,
      activeTab: 'overview',   // 'overview' | 'details' | 'students'
      selectedCardId: '',
      isDemoMode: false,
      ignoredEventTitles: [],
      students: [],
      eventsByMonth: {},       // { 'YYYY-MM': NormalizedEvent[] }
      lastSyncByMonth: {},     // { 'YYYY-MM': 'YYYY/MM/DD HH:mm' }
      monthAdjustments: {}     // { 'YYYY-MM': { sessionOverrides, manualSessions, cardExtras, paidMap } }
    };
  }

  let state = loadState();

  function loadState() {
    const base = getDefaultState();
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const urlClientId = urlParams.get('client_id');

      const raw = localStorage.getItem(CFG.STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        Object.assign(base, parsed);
      }
      if (urlClientId) {
        base.clientId = urlClientId.trim();
      } else if (!base.clientId && CFG.DEFAULT_GOOGLE_CLIENT_ID) {
        base.clientId = CFG.DEFAULT_GOOGLE_CLIENT_ID;
      }
    } catch (e) {
      console.warn('讀取本機快取失敗，使用預設值：', e);
    }
    return base;
  }

  function saveState() {
    try {
      localStorage.setItem(CFG.STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      showToast('本機儲存空間已滿或受限，建議匯出備份檔保存。', 'error');
    }
  }

  function uid(prefix = 'id') {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  }

  function format2(n) {
    return String(n).padStart(2, '0');
  }

  function ymKey(year, month) {
    return `${year}-${format2(month)}`;
  }

  function ymCompact(year, month) {
    return `${year}${format2(month)}`;
  }

  function formatMoney(n) {
    const val = Math.round(Number(n) || 0);
    return val.toLocaleString('en-US');
  }

  function escHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function getMonthAdj(ym) {
    if (!state.monthAdjustments[ym]) {
      state.monthAdjustments[ym] = {
        sessionOverrides: {},
        manualSessions: {},
        cardExtras: {},
        paidMap: {}
      };
    }
    const adj = state.monthAdjustments[ym];
    if (!adj.sessionOverrides) adj.sessionOverrides = {};
    if (!adj.manualSessions) adj.manualSessions = {};
    if (!adj.cardExtras) adj.cardExtras = {};
    if (!adj.paidMap) adj.paidMap = {};
    return adj;
  }

  // --- Toast 通知 ---
  function showToast(msg, type = 'info') {
    const box = document.getElementById('toastContainer');
    if (!box) return;
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.textContent = msg;
    box.appendChild(el);
    requestAnimationFrame(() => el.classList.add('visible'));
    setTimeout(() => {
      el.classList.remove('visible');
      setTimeout(() => el.remove(), 260);
    }, 3400);
  }

  // --- 智慧解析未歸戶日曆標題：剝除表情符號與尾端樂器名 ---
  function extractSuggestedStudentInfo(rawTitle) {
    let cleaned = String(rawTitle || '')
      // 移除常見符號與音樂 emoji
      .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}♪♫♬♩♭♮♯]/gu, '')
      .trim();

    let detectedCourse = '';
    for (const suffix of CFG.INSTRUMENT_SUFFIXES) {
      const re = new RegExp(`\\s*${suffix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*$`, 'i');
      if (re.test(cleaned)) {
        const candidate = cleaned.replace(re, '').trim();
        if (candidate.length > 0) {
          cleaned = candidate;
          if (/大提琴|cello/i.test(suffix)) detectedCourse = '大提琴課';
          else if (/小提琴|violin/i.test(suffix)) detectedCourse = '小提琴課';
          else if (/鋼琴|piano/i.test(suffix)) detectedCourse = '鋼琴課';
          else if (/長笛/i.test(suffix)) detectedCourse = '長笛課';
          else if (/吉他/i.test(suffix)) detectedCourse = '吉他課';
          break;
        }
      }
    }
    return {
      studentName: cleaned || rawTitle.trim(),
      courseName: detectedCourse
    };
  }

  // --- 判斷某筆行程是否被排除（請假／停課／已忽略關鍵字） ---
  function isGloballyIgnoredEvent(ev) {
    const titleLower = String(ev.title || '').toLowerCase();
    for (const kw of CFG.DEFAULT_EXCLUDE_KEYWORDS) {
      if (kw && titleLower.includes(kw.toLowerCase())) return true;
    }
    for (const kw of (state.ignoredEventTitles || [])) {
      if (kw && titleLower.includes(kw.toLowerCase())) return true;
    }
    return false;
  }

  /**
   * 將單筆日曆活動比對至對應的學生陣列
   * 若一個活動同時包含兩位獨立兄弟姊妹關鍵字（如「昱丞昱雙鋼琴」且兩人分開建檔）會同時匹配；
   * 但若一個關鍵字是另一個已匹配更長關鍵字的子字串（如「小玉」vs「小玉小孩」），則優先歸給較長關鍵字的學生。
   */
  function matchEventToStudents(ev, students) {
    const titleLower = String(ev.title || '').toLowerCase();
    const hits = [];

    for (const stu of students) {
      const kws = (stu.keywords || []).map((k) => String(k || '').trim()).filter(Boolean);
      let bestKw = '';
      for (const kw of kws) {
        if (titleLower.includes(kw.toLowerCase())) {
          if (kw.length > bestKw.length) bestKw = kw;
        }
      }
      if (bestKw) {
        hits.push({ stu, matchedKw: bestKw.toLowerCase() });
      }
    }

    if (hits.length <= 1) return hits.map((h) => h.stu);

    // 過濾掉關鍵字完全包含於另一位命中學生更長關鍵字內的情況
    return hits
      .filter((h, idx) => !hits.some((other, oIdx) =>
        oIdx !== idx &&
        other.matchedKw.length > h.matchedKw.length &&
        other.matchedKw.includes(h.matchedKw)
      ))
      .map((h) => h.stu);
  }

  function calcDefaultSessionAmount(stu, durationMin) {
    const rate = Number(stu.rate) || 0;
    if (stu.pricingMode === 'by_duration') {
      const mins = Number(durationMin) > 0 ? Number(durationMin) : 60;
      return Math.round((rate * mins) / 60);
    }
    return Math.round(rate);
  }

  function formatDateShort(month, day) {
    return `${month}月${day}日`;
  }

  function formatDateWithWeekday(month, day, weekday) {
    return `${month}月${day}日 (${WEEKDAY_ZH[weekday] || ''})`;
  }

  /**
   * 核心計算引擎：組出指定年月的「個別明細卡 (detailCards)」、「薪資總表 (summaryRows)」與「未歸戶行程 (unmatchedGroups)」
   */
  function buildMonthlyReport(year, month) {
    const ym = ymKey(year, month);
    const rawEvents = state.eventsByMonth[ym] || [];
    const adj = getMonthAdj(ym);
    const students = state.students || [];

    const studentEventsMap = new Map(); // stu.id -> Event[]
    students.forEach((s) => studentEventsMap.set(s.id, []));

    const unmatchedMap = new Map(); // suggestedName -> { suggestedName, courseName, rawTitles: Set, count, sampleDates: [] }
    let matchedEventCount = 0;

    for (const ev of rawEvents) {
      if (isGloballyIgnoredEvent(ev)) continue;
      const matchedStudents = matchEventToStudents(ev, students);
      if (matchedStudents.length > 0) {
        matchedEventCount++;
        matchedStudents.forEach((stu) => {
          studentEventsMap.get(stu.id).push(ev);
        });
      } else {
        const info = extractSuggestedStudentInfo(ev.title);
        const key = info.studentName.toLowerCase();
        if (!unmatchedMap.has(key)) {
          unmatchedMap.set(key, {
            key,
            suggestedName: info.studentName,
            courseName: info.courseName,
            rawTitles: new Set(),
            count: 0,
            sampleDates: []
          });
        }
        const grp = unmatchedMap.get(key);
        grp.rawTitles.add(ev.title);
        grp.count++;
        if (grp.sampleDates.length < 4) {
          grp.sampleDates.push(`${ev.month}/${ev.day}`);
        }
      }
    }

    // 1. 建立 Detail Cards（支援「獨立明細」與「merged_both 同一張家庭明細合併顯示」）
    const detailCards = [];
    const mergedFamilyBuckets = new Map(); // groupName -> Student[]

    students.forEach((stu) => {
      const grp = String(stu.groupName || '').trim();
      if (grp && stu.groupDetailMode === 'merged_both') {
        if (!mergedFamilyBuckets.has(grp)) mergedFamilyBuckets.set(grp, []);
        mergedFamilyBuckets.get(grp).push(stu);
      } else {
        detailCards.push(buildSingleOrMergedCard([stu], false, grp, year, month, studentEventsMap, adj));
      }
    });

    mergedFamilyBuckets.forEach((familyStudents, grpName) => {
      detailCards.push(buildSingleOrMergedCard(familyStudents, true, grpName, year, month, studentEventsMap, adj));
    });

    // 依學生原始順序排序 detailCards
    const stuOrder = new Map(students.map((s, i) => [s.id, i]));
    detailCards.sort((a, b) => (stuOrder.get(a.primaryStudentId) ?? 999) - (stuOrder.get(b.primaryStudentId) ?? 999));

    // 2. 建立「每月家教薪資收入總表 (summaryRows)」（無論 separate_detail_merged_summary 或 merged_both，只要同 groupName 都在總表合併加總！）
    const summaryMap = new Map();
    const summaryRows = [];

    detailCards.forEach((card) => {
      const grp = card.groupName;
      const sumKey = grp ? `grp::${grp}` : `stu::${card.primaryStudentId}`;

      if (!summaryMap.has(sumKey)) {
        const row = {
          sumKey,
          label: grp || card.summaryLabel || card.studentLabel,
          sessionCount: 0,
          totalMinutes: 0,
          lessonSubtotal: 0,
          extraSubtotal: 0,
          totalAmount: 0,
          sourceCardIds: [],
          memberStudents: [],
          memberBreakdowns: [],
          paid: Boolean(adj.paidMap[sumKey])
        };
        summaryMap.set(sumKey, row);
        summaryRows.push(row);
      }

      const target = summaryMap.get(sumKey);
      target.sessionCount += card.sessions.length;
      target.totalMinutes += card.totalMinutes;
      target.lessonSubtotal += card.lessonSubtotal;
      target.extraSubtotal += card.extraSubtotal;
      target.totalAmount += card.totalAmount;
      target.sourceCardIds.push(card.cardId);
      card.students.forEach((s) => {
        if (!target.memberStudents.some((m) => m.id === s.id)) {
          target.memberStudents.push(s);
        }
      });
      if (grp && !card.isMergedFamily) {
        target.memberBreakdowns.push(`${card.studentLabel} ${formatMoney(card.totalAmount)}`);
      }
    });

    summaryRows.forEach((r) => {
      r.breakdownNote = r.memberBreakdowns.length > 1 ? r.memberBreakdowns.join(' ＋ ') : '';
    });

    const grandTotal = summaryRows.reduce((acc, r) => acc + r.totalAmount, 0);
    const totalSessions = summaryRows.reduce((acc, r) => acc + r.sessionCount, 0);
    const totalMinutes = summaryRows.reduce((acc, r) => acc + r.totalMinutes, 0);
    const paidTotal = summaryRows.filter((r) => r.paid).reduce((acc, r) => acc + r.totalAmount, 0);

    return {
      year,
      month,
      ym,
      rawEventCount: rawEvents.length,
      matchedEventCount,
      unmatchedGroups: Array.from(unmatchedMap.values()),
      detailCards,
      summaryRows,
      grandTotal,
      paidTotal,
      totalSessions,
      totalMinutes
    };
  }

  function buildSingleOrMergedCard(cardStudents, isMergedFamily, groupName, year, month, studentEventsMap, adj) {
    const firstStu = cardStudents[0];
    const cardId = isMergedFamily ? `grp_${groupName}` : `stu_${firstStu.id}`;
    const studentLabel = isMergedFamily ? groupName : firstStu.name;
    const summaryLabel = isMergedFamily ? groupName : (firstStu.summaryLabel || firstStu.name);

    // 課程名稱標題（如：大提琴課）
    const courses = Array.from(new Set(cardStudents.map((s) => s.courseName).filter(Boolean)));
    const courseTitle = courses.join('／');

    // 收集所有對應的日曆課堂
    const activeSessions = [];
    const excludedSessions = [];

    cardStudents.forEach((stu) => {
      const evs = studentEventsMap.get(stu.id) || [];
      evs.forEach((ev) => {
        const ovKey = `${stu.id}::${ev.id}`;
        const ov = adj.sessionOverrides[ovKey] || {};
        const defaultAmt = calcDefaultSessionAmount(stu, ev.durationMin);
        const hasCustom = ov.customAmount !== undefined && ov.customAmount !== null && ov.customAmount !== '';
        const finalAmt = hasCustom ? Math.round(Number(ov.customAmount) || 0) : defaultAmt;

        const sessObj = {
          sessionKey: ovKey,
          isManual: false,
          studentId: stu.id,
          studentName: stu.name,
          eventTitle: ev.title,
          dateStr: ev.dateStr,
          dateShortLabel: formatDateShort(ev.month, ev.day),
          dateDisplay: formatDateWithWeekday(ev.month, ev.day, ev.weekday),
          timeLabel: ev.timeLabel,
          durationMin: ev.durationMin,
          defaultAmount: defaultAmt,
          amount: finalAmt,
          isCustomAmount: hasCustom,
          note: ov.note || '',
          excluded: Boolean(ov.excluded),
          sortTs: ev.sortTs
        };

        if (sessObj.excluded) excludedSessions.push(sessObj);
        else activeSessions.push(sessObj);
      });
    });

    // 加入該明細卡手動補登的課堂
    const manuals = adj.manualSessions[cardId] || [];
    manuals.forEach((m) => {
      const parts = String(m.dateStr || `${year}-${format2(month)}-01`).split('-').map(Number);
      const my = parts[0] || year;
      const mm = parts[1] || month;
      const md = parts[2] || 1;
      const dt = new Date(my, mm - 1, md, 12, 0, 0);
      activeSessions.push({
        sessionKey: m.id,
        manualId: m.id,
        isManual: true,
        studentId: firstStu.id,
        studentName: m.studentName || studentLabel,
        eventTitle: '手動補登課堂',
        dateStr: `${my}-${format2(mm)}-${format2(md)}`,
        dateShortLabel: formatDateShort(mm, md),
        dateDisplay: formatDateWithWeekday(mm, md, dt.getDay()),
        timeLabel: '手動補登',
        durationMin: Number(m.durationMin) || 60,
        defaultAmount: Math.round(Number(m.amount) || 0),
        amount: Math.round(Number(m.amount) || 0),
        isCustomAmount: false,
        note: m.note || '補課',
        excluded: false,
        sortTs: dt.getTime()
      });
    });

    activeSessions.sort((a, b) => a.sortTs - b.sortTs || a.studentName.localeCompare(b.studentName, 'zh-Hant'));
    excludedSessions.sort((a, b) => a.sortTs - b.sortTs);

    // 書費 / 其他費用列（預設至少有一列空白「書費/其他費用」方便直接填寫，完全比照截圖 1！）
    let extras = adj.cardExtras[cardId];
    if (!Array.isArray(extras) || extras.length === 0) {
      extras = [{ id: 'default_extra', label: '書費/其他費用', amount: '', note: '' }];
    }

    const lessonSubtotal = activeSessions.reduce((acc, s) => acc + s.amount, 0);
    const extraSubtotal = extras.reduce((acc, ex) => acc + (Math.round(Number(ex.amount) || 0)), 0);
    const totalMinutes = activeSessions.reduce((acc, s) => acc + (Number(s.durationMin) || 60), 0);

    const usesDuration = cardStudents.some((s) => s.pricingMode === 'by_duration');
    const rateHeaderLabel = usesDuration ? '鐘點費/60m換算' : '鐘點費/堂';

    return {
      cardId,
      primaryStudentId: firstStu.id,
      students: cardStudents,
      isMergedFamily,
      groupName,
      tabTitle: studentLabel,
      studentLabel,
      summaryLabel,
      courseTitle,
      rateHeaderLabel,
      sessions: activeSessions,
      excludedSessions,
      extras,
      lessonSubtotal,
      extraSubtotal,
      totalMinutes,
      totalAmount: lessonSubtotal + extraSubtotal
    };
  }

  // =========================================================================
  // UI 渲染函式
  // =========================================================================

  function renderAll() {
    const report = buildMonthlyReport(state.activeYear, state.activeMonth);
    window.__latestReport = report;

    renderSyncStatus();
    renderBannersAndWelcome(report);
    renderMonthBar();
    renderKpis(report);
    renderUnmatchedPanel(report);
    renderTabsState(report);
    renderOverviewSplit(report);
    renderAllDetailsGrid(report);
    renderStudentsConfigTable();
  }

  function renderSyncStatus() {
    const badge = document.getElementById('syncStatusBadge');
    const txt = document.getElementById('syncStatusText');
    const btnLabel = document.getElementById('btnGoogleSignInLabel');
    const tokenRec = window.GoogleCalendarSync.getSavedToken(state.clientId);

    const calNames = (state.selectedCalendars || []).map((c) => c.summary).join('、');
    if (tokenRec && calNames) {
      badge.className = 'sync-badge connected';
      txt.textContent = `已連結：${calNames}`;
      btnLabel.textContent = '同步本月日曆';
    } else if (tokenRec) {
      badge.className = 'sync-badge partial';
      txt.textContent = '已登入 Google（請勾選子日曆）';
      btnLabel.textContent = '選擇家教日曆';
    } else if (calNames) {
      badge.className = 'sync-badge partial';
      txt.textContent = `日曆：${calNames}（點右側重新同步）`;
      btnLabel.textContent = 'Google 帳號一鍵同步';
    } else {
      badge.className = 'sync-badge disconnected';
      txt.textContent = '尚未連結 Google 日曆';
      btnLabel.textContent = 'Google 帳號一鍵同步';
    }
  }

  function renderBannersAndWelcome(report) {
    const demoBanner = document.getElementById('demoBanner');
    demoBanner.classList.toggle('hidden', !state.isDemoMode);

    const hasAnyData = state.students.length > 0 || Object.keys(state.eventsByMonth).some((k) => (state.eventsByMonth[k] || []).length > 0);
    const welcome = document.getElementById('welcomeCard');
    welcome.classList.toggle('hidden', hasAnyData);
  }

  function renderMonthBar() {
    const { activeYear: y, activeMonth: m } = state;
    const ym = ymKey(y, m);
    document.getElementById('monthPickerInput').value = ym;
    document.getElementById('currentMonthLabel').textContent = `${y}年 ${m}月`;

    const syncHint = document.getElementById('lastSyncHint');
    const lastSync = state.lastSyncByMonth[ym];
    syncHint.textContent = lastSync ? `最後同步：${lastSync}` : '';

    // 類似 Google Sheet 分頁列：顯示目前選取月份前後共 6 個月份快速切換標籤 (YYYYMM)
    const tabsWrap = document.getElementById('quickMonthTabs');
    const months = [];
    for (let offset = 1; offset >= -4; offset--) {
      const dt = new Date(y, m - 1 + offset, 1);
      months.push({ yy: dt.getFullYear(), mm: dt.getMonth() + 1 });
    }

    tabsWrap.innerHTML = months.map(({ yy, mm }) => {
      const active = yy === y && mm === m;
      const hasEv = (state.eventsByMonth[ymKey(yy, mm)] || []).length > 0;
      return `<button type="button" class="ym-tab ${active ? 'active' : ''} ${hasEv ? 'has-data' : ''}" data-yy="${yy}" data-mm="${mm}">
        ${ymCompact(yy, mm)}
      </button>`;
    }).join('');
  }

  function renderKpis(report) {
    document.getElementById('kpiGrandTotal').textContent = `NT$ ${formatMoney(report.grandTotal)}`;
    const unpaid = report.grandTotal - report.paidTotal;
    document.getElementById('kpiPaidHint').textContent = report.paidTotal > 0
      ? `已收 NT$ ${formatMoney(report.paidTotal)} · 待收 NT$ ${formatMoney(unpaid)}`
      : '課程鐘點 ＋ 書費／其他合計';

    document.getElementById('kpiGroupCount').textContent = `${report.summaryRows.length} 組`;
    document.getElementById('kpiStudentSub').textContent = `共設定 ${state.students.length} 位學生規則`;

    document.getElementById('kpiSessionCount').textContent = `${report.totalSessions} 堂`;
    const hrs = Math.round((report.totalMinutes / 60) * 10) / 10;
    document.getElementById('kpiHoursSub').textContent = `合計授課 ${hrs} 小時`;

    document.getElementById('kpiMatchStatus').textContent = `${report.matchedEventCount} / ${report.rawEventCount} 筆`;
    const unCnt = report.unmatchedGroups.length;
    const unSub = document.getElementById('kpiUnmatchedSub');
    if (report.rawEventCount === 0) {
      unSub.textContent = '本月尚無匯入日曆行程';
      unSub.className = 'kpi-sub';
    } else if (unCnt > 0) {
      unSub.textContent = `⚠️ 有 ${unCnt} 組新行程待設定鐘點費`;
      unSub.className = 'kpi-sub text-warn';
    } else {
      unSub.textContent = '✅ 本月行程已全數對應完成';
      unSub.className = 'kpi-sub text-ok';
    }
  }

  function renderUnmatchedPanel(report) {
    const panel = document.getElementById('unmatchedPanel');
    const groups = report.unmatchedGroups;
    if (groups.length === 0) {
      panel.classList.add('hidden');
      return;
    }
    panel.classList.remove('hidden');
    document.getElementById('unmatchedCountBadge').textContent = String(groups.length);

    const studentOptions = state.students.map((s) =>
      `<option value="${escHtml(s.id)}">歸入現有學生：${escHtml(s.name)}</option>`
    ).join('');

    const listEl = document.getElementById('unmatchedList');
    listEl.innerHTML = groups.map((g, idx) => {
      const rawSample = Array.from(g.rawTitles).join('、');
      return `
        <div class="unmatched-item" data-idx="${idx}">
          <label class="unmatched-check">
            <input type="checkbox" class="unmatched-cb" checked data-name="${escHtml(g.suggestedName)}" data-course="${escHtml(g.courseName)}" />
            <div class="unmatched-info">
              <div class="unmatched-title-row">
                <input type="text" class="inline-name-input unmatched-name-input" value="${escHtml(g.suggestedName)}" title="建立後的學生名稱" />
                <span class="pill-count">本月 ${g.count} 堂 (${escHtml(g.sampleDates.join(', '))})</span>
              </div>
              <div class="unmatched-raw">原日曆標題：${escHtml(rawSample)}</div>
            </div>
          </label>
          <div class="unmatched-controls">
            <input type="number" min="0" step="50" class="inline-rate-input unmatched-rate-input" placeholder="填入鐘點費 (如 1000)" />
            <button type="button" class="btn btn-xs btn-primary btn-create-single">➕ 建立</button>
            ${state.students.length > 0 ? `
              <select class="select-xs unmatched-merge-select" data-keyword="${escHtml(g.suggestedName)}">
                <option value="">或歸入現有學生...</option>
                ${studentOptions}
              </select>
            ` : ''}
            <button type="button" class="btn btn-xs btn-ghost btn-ignore-title" data-keyword="${escHtml(g.suggestedName)}" title="這不是家教課，之後自動忽略">🙈 忽略</button>
          </div>
        </div>
      `;
    }).join('');
  }

  function renderTabsState(report) {
    document.getElementById('tabDetailCount').textContent = String(report.detailCards.length);
    document.getElementById('tabStudentCount').textContent = String(state.students.length);

    document.querySelectorAll('.view-tab').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.tab === state.activeTab);
    });

    document.getElementById('viewOverview').classList.toggle('hidden', state.activeTab !== 'overview');
    document.getElementById('viewDetails').classList.toggle('hidden', state.activeTab !== 'details');
    document.getElementById('viewStudents').classList.toggle('hidden', state.activeTab !== 'students');
  }

  function renderOverviewSplit(report) {
    document.getElementById('summaryTableTitle').textContent = `${report.year}年${report.month}月 每月家教薪資收入`;
    const tbody = document.getElementById('summaryTableBody');

    if (report.detailCards.length > 0) {
      const exists = report.detailCards.some((c) => c.cardId === state.selectedCardId);
      if (!exists) state.selectedCardId = report.detailCards[0].cardId;
    } else {
      state.selectedCardId = '';
    }

    if (report.summaryRows.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6" class="empty-cell">
            尚未建立學生或匯入本月行程。請點上方「<strong>Google 帳號一鍵同步</strong>」或「<strong>➕ 新增學生規則</strong>」！
          </td>
        </tr>
      `;
    } else {
      tbody.innerHTML = report.summaryRows.map((row, idx) => {
        const isSelected = row.sourceCardIds.includes(state.selectedCardId);
        // 若此總表列僅對應單一學生，提供超方便行內直接填寫鐘點費欄位！
        let rateQuickHtml = '';
        if (row.memberStudents.length === 1) {
          const s = row.memberStudents[0];
          const unitTag = s.pricingMode === 'by_duration' ? '/60m' : '/堂';
          const missingClass = (!s.rate || Number(s.rate) === 0) ? 'rate-missing' : '';
          rateQuickHtml = `
            <div class="quick-rate-box" onclick="event.stopPropagation()">
              <input
                type="number"
                min="0"
                step="50"
                class="quick-rate-input ${missingClass}"
                data-stu-id="${escHtml(s.id)}"
                value="${s.rate === '' || s.rate == null ? '' : escHtml(s.rate)}"
                placeholder="填鐘點費"
              />
              <span class="unit-tag">${unitTag}</span>
            </div>
          `;
        } else {
          rateQuickHtml = `<span class="multi-rate-hint" title="家庭內含多位成員，點擊右側可檢視或調整各自鐘點費">家庭合併 (${row.memberStudents.length}人)</span>`;
        }

        return `
          <tr class="summary-row ${isSelected ? 'selected' : ''} ${row.paid ? 'is-paid' : ''}" data-first-card="${escHtml(row.sourceCardIds[0] || '')}">
            <td class="text-center text-muted">${idx + 1}</td>
            <td>
              <div class="sum-name-main">${escHtml(row.label)}</div>
              ${row.breakdownNote ? `<div class="sum-breakdown">${escHtml(row.breakdownNote)}</div>` : ''}
            </td>
            <td class="text-center">${row.sessionCount}</td>
            <td>${rateQuickHtml}</td>
            <td class="sum-amount-cell">${formatMoney(row.totalAmount)}</td>
            <td class="text-center" onclick="event.stopPropagation()">
              <input type="checkbox" class="paid-checkbox" data-sum-key="${escHtml(row.sumKey)}" ${row.paid ? 'checked' : ''} title="標記本月已收款" />
            </td>
          </tr>
        `;
      }).join('');
    }

    document.getElementById('summaryTotalSessionsCell').textContent = String(report.totalSessions);
    document.getElementById('summaryGrandTotalCell').textContent = formatMoney(report.grandTotal);

    // 右欄下拉選單與單張明細渲染
    const sel = document.getElementById('activeCardSelect');
    if (report.detailCards.length === 0) {
      sel.innerHTML = `<option value="">（尚無學生明細）</option>`;
      document.getElementById('activeDetailContainer').innerHTML = `
        <div class="empty-detail-box">
          建立學生或同步 Google 日曆後，此處會自動顯示該學生當月的上課日期與學費明細表。
        </div>
      `;
    } else {
      sel.innerHTML = report.detailCards.map((c) =>
        `<option value="${escHtml(c.cardId)}" ${c.cardId === state.selectedCardId ? 'selected' : ''}>
          📄 ${escHtml(c.studentLabel)}（本月 ${c.sessions.length} 堂 · NT$ ${formatMoney(c.totalAmount)}）
        </option>`
      ).join('');

      const activeCard = report.detailCards.find((c) => c.cardId === state.selectedCardId) || report.detailCards[0];
      document.getElementById('activeDetailContainer').innerHTML = buildDetailSheetHtml(activeCard, report.year, report.month);
    }
  }

  function renderAllDetailsGrid(report) {
    const grid = document.getElementById('viewDetails');
    if (report.detailCards.length === 0) {
      grid.innerHTML = `<div class="panel empty-detail-box">尚未建立任何學生明細，請先同步 Google 日曆或新增學生。</div>`;
      return;
    }
    grid.innerHTML = report.detailCards.map((card) => `
      <div class="panel detail-grid-card">
        <div class="detail-grid-card-top">
          <span class="card-badge">${card.isMergedFamily ? '👨‍👩‍👧‍👦 家庭合併明細' : '🎓 個別學生明細'}</span>
          <div class="detail-card-actions">
            <button type="button" class="btn btn-xs btn-ghost btn-grid-copy" data-card-id="${escHtml(card.cardId)}">📋 複製明細</button>
          </div>
        </div>
        ${buildDetailSheetHtml(card, report.year, report.month)}
      </div>
    `).join('');
  }

  /**
   * 產生完全比照截圖 1 視覺風格的「學生當月費用明細表」HTML（支援行內修改單堂金額、備註、書費、排除與還原）
   */
  function buildDetailSheetHtml(card, year, month) {
    const isMergedMulti = card.isMergedFamily && card.sessions.some((s) => s.studentName !== card.studentLabel);
    const colSpanAll = isMergedMulti ? 4 : 3;
    const courseTitleText = card.courseTitle
      ? `${year}年${month}月份${card.courseTitle}費用明細`
      : `${year}年${month}月份課程費用明細`;

    // 上方快速調整此學生預設鐘點費列
    const stuRatePills = card.students.map((s) => `
      <div class="stu-rate-inline-bar">
        <span class="stu-rate-name">⚙️ ${escHtml(s.name)} 預設鐘點費：</span>
        <input
          type="number"
          min="0"
          step="50"
          class="inline-rate-input stu-base-rate-input ${!s.rate ? 'rate-missing' : ''}"
          data-stu-id="${escHtml(s.id)}"
          value="${s.rate === '' || s.rate == null ? '' : escHtml(s.rate)}"
          placeholder="請填入金額"
        />
        <select class="select-xs stu-mode-select" data-stu-id="${escHtml(s.id)}">
          <option value="per_session" ${s.pricingMode === 'per_session' ? 'selected' : ''}>元 / 堂（固定）</option>
          <option value="by_duration" ${s.pricingMode === 'by_duration' ? 'selected' : ''}>元 / 60分鐘（依時長換算）</option>
        </select>
        <button type="button" class="btn btn-xs btn-ghost btn-edit-stu-modal" data-stu-id="${escHtml(s.id)}" title="編輯關鍵字、課程名與家庭合併">編輯規則</button>
      </div>
    `).join('');

    const sessionRowsHtml = card.sessions.length === 0
      ? `<tr>
          <td colspan="${colSpanAll}" class="empty-session-cell">本月尚無對應的上課日期（可檢查日曆關鍵字或點上方「➕ 補登課堂」）</td>
        </tr>`
      : card.sessions.map((sess) => `
        <tr class="detail-session-row ${sess.isCustomAmount ? 'has-override' : ''}">
          <td class="sheet-date-cell" title="${escHtml(sess.eventTitle)} (${escHtml(sess.timeLabel)}, ${sess.durationMin}分鐘)">
            <div class="date-main">${escHtml(sess.dateDisplay)}</div>
            <div class="date-sub">${escHtml(sess.timeLabel)} · ${sess.durationMin}m</div>
          </td>
          ${isMergedMulti ? `<td class="text-center">${escHtml(sess.studentName)}</td>` : ''}
          <td class="sheet-amount-cell">
            <div class="cell-amount-wrap">
              <input
                type="number"
                step="10"
                class="sheet-cell-input amount-input"
                data-card-id="${escHtml(card.cardId)}"
                data-session-key="${escHtml(sess.sessionKey)}"
                data-is-manual="${sess.isManual ? '1' : '0'}"
                value="${sess.amount}"
                title="可直接修改單堂金額"
              />
              ${sess.isCustomAmount ? `<button type="button" class="btn-reset-override" data-session-key="${escHtml(sess.sessionKey)}" title="還原為預設鐘點費 (${sess.defaultAmount})">↺</button>` : ''}
            </div>
          </td>
          <td class="sheet-note-cell">
            <div class="cell-note-wrap">
              <input
                type="text"
                class="sheet-cell-input note-input"
                data-card-id="${escHtml(card.cardId)}"
                data-session-key="${escHtml(sess.sessionKey)}"
                data-is-manual="${sess.isManual ? '1' : '0'}"
                value="${escHtml(sess.note)}"
                placeholder="備註..."
              />
              <button
                type="button"
                class="btn-exclude-session"
                data-card-id="${escHtml(card.cardId)}"
                data-session-key="${escHtml(sess.sessionKey)}"
                data-is-manual="${sess.isManual ? '1' : '0'}"
                title="${sess.isManual ? '刪除此筆手動補課' : '將此日標記為請假／不計費'}"
              >✕</button>
            </div>
          </td>
        </tr>
      `).join('');

    const extraRowsHtml = card.extras.map((ex, idx) => `
      <tr class="detail-extra-row">
        <td class="sheet-extra-label-cell" ${isMergedMulti ? 'colspan="2"' : ''}>
          <input
            type="text"
            class="sheet-cell-input extra-label-input"
            data-card-id="${escHtml(card.cardId)}"
            data-extra-idx="${idx}"
            value="${escHtml(ex.label || '書費/其他費用')}"
          />
        </td>
        <td class="sheet-extra-amount-cell">
          <input
            type="number"
            step="10"
            class="sheet-cell-input extra-amount-input"
            data-card-id="${escHtml(card.cardId)}"
            data-extra-idx="${idx}"
            value="${ex.amount === '' || ex.amount == null ? '' : escHtml(ex.amount)}"
            placeholder="0"
          />
        </td>
        <td class="sheet-extra-note-cell">
          <div class="cell-note-wrap">
            <input
              type="text"
              class="sheet-cell-input extra-note-input"
              data-card-id="${escHtml(card.cardId)}"
              data-extra-idx="${idx}"
              value="${escHtml(ex.note || '')}"
              placeholder="教材或費用說明..."
            />
            ${card.extras.length > 1 ? `<button type="button" class="btn-remove-extra" data-card-id="${escHtml(card.cardId)}" data-extra-idx="${idx}" title="刪除此費用列">✕</button>` : ''}
          </div>
        </td>
      </tr>
    `).join('');

    const excludedRestoreHtml = card.excludedSessions.length > 0
      ? `<div class="excluded-Hint">
          <span>已排除不計費課堂（請假）：</span>
          ${card.excludedSessions.map((ex) => `
            <button type="button" class="chip-restore-session" data-session-key="${escHtml(ex.sessionKey)}" title="點擊恢復計費">
              ↩ 恢復 ${escHtml(ex.dateShortLabel)} (${escHtml(ex.studentName)})
            </button>
          `).join('')}
        </div>`
      : '';

    return `
      <div class="stu-rate-bars">${stuRatePills}</div>
      <div class="spreadsheet-frame">
        <table class="classic-detail-sheet">
          <thead>
            <tr>
              <th colspan="${colSpanAll}" class="classic-purple-header">${escHtml(courseTitleText)}</th>
            </tr>
            <tr>
              <th colspan="${colSpanAll}" class="classic-purple-subheader">學生：${escHtml(card.studentLabel)}</th>
            </tr>
            <tr class="classic-gray-cols">
              <th>上課日期</th>
              ${isMergedMulti ? '<th>學生</th>' : ''}
              <th>${escHtml(card.rateHeaderLabel)}</th>
              <th>其他</th>
            </tr>
          </thead>
          <tbody>
            ${sessionRowsHtml}
            ${extraRowsHtml}
          </tbody>
          <tfoot>
            <tr class="classic-blue-total">
              <td ${isMergedMulti ? 'colspan="2"' : ''}>合計</td>
              <td class="classic-total-num">${formatMoney(card.totalAmount)}</td>
              <td class="classic-total-meta">共 ${card.sessions.length} 堂課</td>
            </tr>
          </tfoot>
        </table>
      </div>
      ${excludedRestoreHtml}
    `;
  }

  function renderStudentsConfigTable() {
    const tbody = document.getElementById('studentsConfigBody');
    if (state.students.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" class="empty-cell">尚未建立任何學生規則。你可以先同步 Google 日曆自動偵測，或點右上角「➕ 新增學生」手動建立。</td>
        </tr>
      `;
    } else {
      tbody.innerHTML = state.students.map((s) => `
        <tr data-stu-id="${escHtml(s.id)}">
          <td><strong>${escHtml(s.name)}</strong>${s.summaryLabel && s.summaryLabel !== s.name ? `<div class="sub-hint">總表簡稱：${escHtml(s.summaryLabel)}</div>` : ''}</td>
          <td>${escHtml(s.courseName || '—')}</td>
          <td>
            <div class="kw-tags">
              ${(s.keywords || []).map((k) => `<span class="kw-tag">${escHtml(k)}</span>`).join('')}
            </div>
          </td>
          <td>
            <select class="select-xs cfg-mode-select" data-stu-id="${escHtml(s.id)}">
              <option value="per_session" ${s.pricingMode === 'per_session' ? 'selected' : ''}>每堂固定金額</option>
              <option value="by_duration" ${s.pricingMode === 'by_duration' ? 'selected' : ''}>依 60m 時長換算</option>
            </select>
          </td>
          <td>
            <input type="number" min="0" step="50" class="inline-rate-input cfg-rate-input" data-stu-id="${escHtml(s.id)}" value="${s.rate === '' || s.rate == null ? '' : escHtml(s.rate)}" placeholder="填金額" />
          </td>
          <td>
            <input type="text" class="inline-group-input cfg-group-input" data-stu-id="${escHtml(s.id)}" value="${escHtml(s.groupName || '')}" placeholder="如：燦燦、伯寧" />
          </td>
          <td>
            <select class="select-xs cfg-gmode-select" data-stu-id="${escHtml(s.id)}" ${!s.groupName ? 'disabled' : ''}>
              <option value="separate_detail_merged_summary" ${s.groupDetailMode !== 'merged_both' ? 'selected' : ''}>獨立明細＋總表合併</option>
              <option value="merged_both" ${s.groupDetailMode === 'merged_both' ? 'selected' : ''}>同張家庭明細＋總表合併</option>
            </select>
          </td>
          <td class="nowrap">
            <button type="button" class="btn btn-xs btn-outline btn-edit-stu-modal" data-stu-id="${escHtml(s.id)}">編輯</button>
            <button type="button" class="btn btn-xs btn-ghost text-danger btn-delete-stu" data-stu-id="${escHtml(s.id)}">刪除</button>
          </td>
        </tr>
      `).join('');
    }

    const igBox = document.getElementById('ignoredKeywordsBox');
    const igChips = document.getElementById('ignoredChips');
    if (state.ignoredEventTitles && state.ignoredEventTitles.length > 0) {
      igBox.classList.remove('hidden');
      igChips.innerHTML = state.ignoredEventTitles.map((kw) => `
        <span class="ignored-chip">
          ${escHtml(kw)}
          <button type="button" class="btn-remove-ignored" data-kw="${escHtml(kw)}" title="移除忽略">✕</button>
        </span>
      `).join('');
    } else {
      igBox.classList.add('hidden');
    }
  }

  // =========================================================================
  // Google 日曆同步流程與 Modal 互動
  // =========================================================================

  function openModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
  }

  function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  }

  function openSyncSettingsModal() {
    document.getElementById('inputGoogleClientId').value = state.clientId || '';
    document.getElementById('currentOriginCode').textContent = window.location.origin;
    renderCalendarChecklistInModal();
    openModal('syncModal');
  }

  function renderCalendarChecklistInModal() {
    const sec = document.getElementById('calendarSelectSection');
    const listEl = document.getElementById('calendarChecklist');
    const tokenRec = window.GoogleCalendarSync.getSavedToken(state.clientId);

    if (!tokenRec && (!state.cachedCalendars || state.cachedCalendars.length === 0)) {
      sec.classList.add('hidden');
      return;
    }
    sec.classList.remove('hidden');

    const selectedSet = new Set((state.selectedCalendars || []).map((c) => c.id));
    const cals = state.cachedCalendars || [];

    if (cals.length === 0) {
      listEl.innerHTML = `<div class="field-hint">正在讀取日曆清單，請點「🔄 重新整理清單」...</div>`;
      return;
    }

    listEl.innerHTML = cals.map((c) => {
      const checked = selectedSet.has(c.id);
      return `
        <label class="cal-check-item ${checked ? 'checked' : ''}">
          <input type="checkbox" class="cal-item-cb" value="${escHtml(c.id)}" data-summary="${escHtml(c.summary)}" ${checked ? 'checked' : ''} />
          <span class="cal-color-dot" style="background:${escHtml(c.backgroundColor)}"></span>
          <span class="cal-item-name">${escHtml(c.summary)}</span>
          ${c.primary ? '<span class="cal-primary-tag">主日曆</span>' : ''}
        </label>
      `;
    }).join('');
  }

  async function handleGoogleLoginAndSync(forceOpenModalIfNoCal = true) {
    if (!state.clientId) {
      openSyncSettingsModal();
      showToast('請先填入 Google OAuth Client ID（內附 2 分鐘取得步驟）或直接匯入 .ics 日曆檔！', 'info');
      return;
    }

    try {
      let tokenRec = window.GoogleCalendarSync.getSavedToken(state.clientId);
      if (!tokenRec) {
        tokenRec = await window.GoogleCalendarSync.signInWithGoogle(state.clientId, false);
      }

      // 取得子日曆清單
      const cals = await window.GoogleCalendarSync.fetchCalendarList(tokenRec.accessToken);
      state.cachedCalendars = cals;

      // 若尚未選擇過任何子日曆，智慧預選名稱含「家教」的子日曆，否則開啟清單讓使用者勾選
      if (!state.selectedCalendars || state.selectedCalendars.length === 0) {
        const autoTutorCals = cals.filter((c) => /家教/.test(c.summary));
        if (autoTutorCals.length > 0) {
          state.selectedCalendars = autoTutorCals.map((c) => ({ id: c.id, summary: c.summary }));
          saveState();
        } else if (forceOpenModalIfNoCal) {
          saveState();
          openSyncSettingsModal();
          showToast('登入成功！請勾選你要讀取的家教子日曆（例如：個人家教）。', 'info');
          renderSyncStatus();
          return;
        }
      }

      saveState();
      renderCalendarChecklistInModal();
      await syncActiveMonthFromGoogle(tokenRec.accessToken);
    } catch (err) {
      showToast(err.message || '連結 Google 日曆失敗', 'error');
    }
  }

  async function syncActiveMonthFromGoogle(existingAccessToken = '') {
    if (!state.clientId) {
      openSyncSettingsModal();
      return;
    }
    if (!state.selectedCalendars || state.selectedCalendars.length === 0) {
      openSyncSettingsModal();
      showToast('請先勾選至少一個要同步的 Google 子日曆！', 'info');
      return;
    }

    const syncBtn = document.getElementById('btnSyncCurrentMonth');
    const origText = syncBtn.textContent;
    syncBtn.disabled = true;
    syncBtn.textContent = '⏳ 同步中...';

    try {
      let accessToken = existingAccessToken;
      if (!accessToken) {
        let tokenRec = window.GoogleCalendarSync.getSavedToken(state.clientId);
        if (!tokenRec) {
          tokenRec = await window.GoogleCalendarSync.signInWithGoogle(state.clientId, false);
        }
        accessToken = tokenRec.accessToken;
      }

      const { activeYear: y, activeMonth: m } = state;
      const events = await window.GoogleCalendarSync.fetchMonthEvents(accessToken, state.selectedCalendars, y, m);

      if (state.isDemoMode) {
        state.isDemoMode = false;
        state.students = [];
        state.eventsByMonth = {};
        state.monthAdjustments = {};
      }

      const ym = ymKey(y, m);
      state.eventsByMonth[ym] = events;
      const now = new Date();
      state.lastSyncByMonth[ym] = `${now.getMonth() + 1}/${now.getDate()} ${format2(now.getHours())}:${format2(now.getMinutes())}`;
      saveState();
      renderAll();
      showToast(`已成功同步 ${y}年${m}月 共 ${events.length} 筆日曆行程！`, 'success');
    } catch (err) {
      showToast(err.message || '同步本月行程失敗', 'error');
    } finally {
      syncBtn.disabled = false;
      syncBtn.textContent = origText;
    }
  }

  // --- 切換月份（若已登入 Google 且該月尚未抓過行程，自動從 Google 同步！） ---
  async function changeActiveMonth(newYear, newMonth) {
    let y = newYear;
    let m = newMonth;
    while (m < 1) { m += 12; y -= 1; }
    while (m > 12) { m -= 12; y += 1; }
    state.activeYear = y;
    state.activeMonth = m;
    saveState();
    renderAll();

    const ym = ymKey(y, m);
    const tokenRec = window.GoogleCalendarSync.getSavedToken(state.clientId);
    if (tokenRec && state.selectedCalendars.length > 0 && !state.eventsByMonth[ym] && !state.isDemoMode) {
      await syncActiveMonthFromGoogle(tokenRec.accessToken);
    }
  }

  // --- 複製文字明細（方便貼 LINE 給家長） ---
  function formatCardAsPlainText(card, year, month) {
    const header = card.courseTitle
      ? `【${year}年${month}月份${card.courseTitle}費用明細】`
      : `【${year}年${month}月份課程費用明細】`;
    const lines = [header, `學生：${card.studentLabel}`, '──────────────'];
    const isMergedMulti = card.isMergedFamily && card.sessions.some((s) => s.studentName !== card.studentLabel);

    card.sessions.forEach((s) => {
      const who = isMergedMulti ? ` (${s.studentName})` : '';
      const note = s.note ? ` [${s.note}]` : '';
      lines.push(`• ${s.dateShortLabel}${who}：NT$ ${formatMoney(s.amount)}${note}`);
    });

    card.extras.forEach((ex) => {
      if (ex.amount !== '' && ex.amount != null && Number(ex.amount) !== 0) {
        const note = ex.note ? ` (${ex.note})` : '';
        lines.push(`• ${ex.label || '書費/其他費用'}${note}：NT$ ${formatMoney(ex.amount)}`);
      }
    });

    lines.push('──────────────');
    lines.push(`合計（共 ${card.sessions.length} 堂）：NT$ ${formatMoney(card.totalAmount)}`);
    return lines.join('\n');
  }

  async function copyTextToClipboard(text, okMsg) {
    try {
      await navigator.clipboard.writeText(text);
      showToast(okMsg, 'success');
    } catch (_) {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      showToast(okMsg, 'success');
    }
  }

  // =========================================================================
  // 事件綁定 (Event Delegation + Modal Controls)
  // =========================================================================

  function bindEvents() {
    // IME 安全 Enter 送出輔助：輸入框按 Enter (非注音選字中) 自動觸發 blur -> change
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) {
        const tag = e.target && e.target.tagName;
        if (tag === 'INPUT' && e.target.form == null) {
          e.preventDefault();
          e.target.blur();
        }
      }
      if (e.key === 'Escape') {
        ['syncModal', 'studentModal', 'backupModal'].forEach(closeModal);
      }
    });

    // 關閉各 Modal
    document.querySelectorAll('[data-close-modal]').forEach((btn) => {
      btn.addEventListener('click', () => closeModal(btn.dataset.closeModal));
    });
    document.querySelectorAll('.modal-backdrop').forEach((bd) => {
      bd.addEventListener('click', (e) => {
        if (e.target === bd) bd.classList.add('hidden');
      });
    });

    // 頂部導覽按鈕
    document.getElementById('btnGoogleSignIn').addEventListener('click', () => handleGoogleLoginAndSync(true));
    document.getElementById('syncStatusBadge').addEventListener('click', openSyncSettingsModal);
    document.getElementById('btnOpenSyncModal').addEventListener('click', openSyncSettingsModal);
    document.getElementById('btnWelcomeSync').addEventListener('click', () => handleGoogleLoginAndSync(true));
    document.getElementById('btnWelcomeIcs').addEventListener('click', openSyncSettingsModal);

    // 載入／退出範例資料
    const loadDemoHandler = () => {
      const { demoStudents, eventsByMonth } = window.IcsHelper.generateDemoDataset(state.activeYear, state.activeMonth);
      state.isDemoMode = true;
      state.students = demoStudents;
      state.eventsByMonth = eventsByMonth;
      state.monthAdjustments = {};
      // 為東真那示範加一筆書費範例，也可隨時清除
      const ym = ymKey(state.activeYear, state.activeMonth);
      getMonthAdj(ym).cardExtras['stu_demo_s1'] = [{ id: 'ex1', label: '書費/其他費用', amount: '', note: '' }];
      saveState();
      closeModal('syncModal');
      renderAll();
      showToast('已載入範例家教資料！可自由切換月份、修改鐘點費或匯出 Excel (.xlsx)。', 'success');
    };
    document.getElementById('btnLoadDemo').addEventListener('click', loadDemoHandler);
    document.getElementById('btnTriggerDemoFromModal').addEventListener('click', loadDemoHandler);

    document.getElementById('btnExitDemo').addEventListener('click', () => {
      state.isDemoMode = false;
      state.students = [];
      state.eventsByMonth = {};
      state.monthAdjustments = {};
      saveState();
      renderAll();
      showToast('已清空範例資料，現在可以連結你的 Google 日曆！', 'info');
    });

    // 匯出本月 Excel (.xlsx)
    document.getElementById('btnExportXlsx').addEventListener('click', () => {
      const report = window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth);
      if (report.detailCards.length === 0) {
        showToast('目前尚無學生明細資料可匯出，請先同步行程或新增學生！', 'error');
        return;
      }
      const fname = window.XlsxExporter.exportMonthlyReportToXlsx(report);
      showToast(`已匯出 Excel 檔案：${fname}`, 'success');
    });

    // 月份切換
    document.getElementById('btnPrevMonth').addEventListener('click', () => changeActiveMonth(state.activeYear, state.activeMonth - 1));
    document.getElementById('btnNextMonth').addEventListener('click', () => changeActiveMonth(state.activeYear, state.activeMonth + 1));
    document.getElementById('monthPickerInput').addEventListener('change', (e) => {
      const val = e.target.value;
      if (/^\d{4}-\d{2}$/.test(val)) {
        const [yy, mm] = val.split('-').map(Number);
        changeActiveMonth(yy, mm);
      }
    });
    document.getElementById('quickMonthTabs').addEventListener('click', (e) => {
      const btn = e.target.closest('.ym-tab');
      if (!btn) return;
      changeActiveMonth(Number(btn.dataset.yy), Number(btn.dataset.mm));
    });
    document.getElementById('btnSyncCurrentMonth').addEventListener('click', () => syncActiveMonthFromGoogle());

    // Sync Modal 內操作
    document.getElementById('btnCopyOrigin').addEventListener('click', () => {
      copyTextToClipboard(window.location.origin, `已複製來源網址：${window.location.origin}`);
    });

    document.getElementById('btnSaveAndLoginGoogle').addEventListener('click', async () => {
      const cid = document.getElementById('inputGoogleClientId').value.trim();
      if (!cid) {
        showToast('請先貼上 Google OAuth Client ID', 'error');
        return;
      }
      state.clientId = cid;
      window.GoogleCalendarSync.clearToken();
      saveState();
      try {
        const tokenRec = await window.GoogleCalendarSync.signInWithGoogle(cid, true);
        const cals = await window.GoogleCalendarSync.fetchCalendarList(tokenRec.accessToken);
        state.cachedCalendars = cals;
        // 智慧預選名稱含「家教」的子日曆
        if (state.selectedCalendars.length === 0) {
          const tutorCals = cals.filter((c) => /家教/.test(c.summary));
          if (tutorCals.length > 0) {
            state.selectedCalendars = tutorCals.map((c) => ({ id: c.id, summary: c.summary }));
          }
        }
        saveState();
        renderCalendarChecklistInModal();
        renderSyncStatus();
        showToast('成功連結 Google 帳號！請確認下方勾選的子日曆並點「立即抓取」。', 'success');
      } catch (err) {
        showToast(err.message || 'Google 登入失敗', 'error');
      }
    });

    document.getElementById('btnRefreshCalendars').addEventListener('click', async () => {
      try {
        let tokenRec = window.GoogleCalendarSync.getSavedToken(state.clientId);
        if (!tokenRec) tokenRec = await window.GoogleCalendarSync.signInWithGoogle(state.clientId, false);
        state.cachedCalendars = await window.GoogleCalendarSync.fetchCalendarList(tokenRec.accessToken);
        saveState();
        renderCalendarChecklistInModal();
        showToast('已更新子日曆清單', 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    });

    document.getElementById('btnGoogleSignOut').addEventListener('click', () => {
      window.GoogleCalendarSync.clearToken();
      renderCalendarChecklistInModal();
      renderSyncStatus();
      showToast('已登出 Google 授權工作階段', 'info');
    });

    document.getElementById('calendarChecklist').addEventListener('change', () => {
      const checked = Array.from(document.querySelectorAll('.cal-item-cb:checked')).map((cb) => ({
        id: cb.value,
        summary: cb.dataset.summary || cb.value
      }));
      state.selectedCalendars = checked;
      saveState();
      renderCalendarChecklistInModal();
      renderSyncStatus();
    });

    document.getElementById('btnSyncSelectedCalendars').addEventListener('click', async () => {
      const checked = Array.from(document.querySelectorAll('.cal-item-cb:checked')).map((cb) => ({
        id: cb.value,
        summary: cb.dataset.summary || cb.value
      }));
      if (checked.length === 0) {
        showToast('請至少勾選一個子日曆（例如：個人家教）', 'error');
        return;
      }
      state.selectedCalendars = checked;
      saveState();
      closeModal('syncModal');
      await syncActiveMonthFromGoogle();
    });

    // 匯入 .ics 日曆檔案
    document.getElementById('inputIcsFile').addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        const { calName, byMonth } = window.IcsHelper.parseIcsContent(text);
        const monthKeys = Object.keys(byMonth).sort();
        if (monthKeys.length === 0) {
          showToast('此 .ics 檔案中沒有找到有效行程', 'error');
          return;
        }
        if (state.isDemoMode) {
          state.isDemoMode = false;
          state.students = [];
          state.eventsByMonth = {};
          state.monthAdjustments = {};
        }
        let totalImported = 0;
        const stamp = `匯入自 ${calName}`;
        monthKeys.forEach((ym) => {
          state.eventsByMonth[ym] = byMonth[ym];
          state.lastSyncByMonth[ym] = stamp;
          totalImported += byMonth[ym].length;
        });

        // 若目前選取的月份剛好沒有行程，跳轉到最近有行程的月份
        const curYm = ymKey(state.activeYear, state.activeMonth);
        if (!byMonth[curYm]) {
          const latestYm = monthKeys[monthKeys.length - 1];
          const [ly, lm] = latestYm.split('-').map(Number);
          state.activeYear = ly;
          state.activeMonth = lm;
        }

        state.selectedCalendars = [{ id: 'ics_import', summary: `${calName} (.ics)` }];
        saveState();
        closeModal('syncModal');
        renderAll();
        showToast(`成功匯入「${calName}」共 ${monthKeys.length} 個月份、${totalImported} 筆課程紀錄！`, 'success');
      } catch (err) {
        showToast(`讀取 .ics 失敗：${err.message}`, 'error');
      } finally {
        e.target.value = '';
      }
    });

    // 未歸戶行程快速建立
    document.getElementById('btnAutoCreateAll').addEventListener('click', () => {
      const items = Array.from(document.querySelectorAll('#unmatchedList .unmatched-item'));
      let added = 0;
      items.forEach((item) => {
        const cb = item.querySelector('.unmatched-cb');
        if (!cb || !cb.checked) return;
        const name = item.querySelector('.unmatched-name-input').value.trim();
        const rateStr = item.querySelector('.unmatched-rate-input').value.trim();
        const course = cb.dataset.course || '';
        if (!name) return;
        state.students.push({
          id: uid('stu'),
          name,
          summaryLabel: '',
          courseName: course,
          keywords: Array.from(new Set([name, cb.dataset.name].filter(Boolean))),
          pricingMode: 'per_session',
          rate: rateStr === '' ? '' : Math.round(Number(rateStr) || 0),
          groupName: '',
          groupDetailMode: 'separate_detail_merged_summary'
        });
        added++;
      });
      if (added > 0) {
        saveState();
        renderAll();
        showToast(`已新增 ${added} 位學生並自動帶入本月上課日期！請確認鐘點費金額。`, 'success');
      }
    });

    document.getElementById('unmatchedList').addEventListener('click', (e) => {
      const createBtn = e.target.closest('.btn-create-single');
      if (createBtn) {
        const item = createBtn.closest('.unmatched-item');
        const cb = item.querySelector('.unmatched-cb');
        const name = item.querySelector('.unmatched-name-input').value.trim();
        const rateStr = item.querySelector('.unmatched-rate-input').value.trim();
        if (!name) return;
        const newStu = {
          id: uid('stu'),
          name,
          summaryLabel: '',
          courseName: cb.dataset.course || '',
          keywords: Array.from(new Set([name, cb.dataset.name].filter(Boolean))),
          pricingMode: 'per_session',
          rate: rateStr === '' ? '' : Math.round(Number(rateStr) || 0),
          groupName: '',
          groupDetailMode: 'separate_detail_merged_summary'
        };
        state.students.push(newStu);
        state.selectedCardId = `stu_${newStu.id}`;
        saveState();
        renderAll();
        showToast(`已新增學生「${name}」！`, 'success');
        return;
      }

      const igBtn = e.target.closest('.btn-ignore-title');
      if (igBtn) {
        const kw = igBtn.dataset.keyword;
        if (kw && !state.ignoredEventTitles.includes(kw)) {
          state.ignoredEventTitles.push(kw);
          saveState();
          renderAll();
          showToast(`已忽略含「${kw}」的行程（可於學生設定頁下方恢復）`, 'info');
        }
      }
    });

    document.getElementById('unmatchedList').addEventListener('change', (e) => {
      const mergeSel = e.target.closest('.unmatched-merge-select');
      if (mergeSel && mergeSel.value) {
        const stu = state.students.find((s) => s.id === mergeSel.value);
        const kw = mergeSel.dataset.keyword;
        if (stu && kw) {
          if (!stu.keywords.includes(kw)) stu.keywords.push(kw);
          saveState();
          renderAll();
          showToast(`已將關鍵字「${kw}」歸入學生「${stu.name}」！`, 'success');
        }
      }
    });

    // 主視圖頁籤切換
    document.querySelectorAll('.view-tab').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.activeTab = btn.dataset.tab;
        saveState();
        renderTabsState(window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth));
      });
    });

    // 左欄「每月薪資總表」點擊切換右側明細、快速填鐘點費、勾選已收款
    document.getElementById('summaryTableBody').addEventListener('click', (e) => {
      const tr = e.target.closest('.summary-row');
      if (!tr || !tr.dataset.firstCard) return;
      state.selectedCardId = tr.dataset.firstCard;
      saveState();
      renderOverviewSplit(window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth));
    });

    document.getElementById('summaryTableBody').addEventListener('change', (e) => {
      if (e.target.classList.contains('quick-rate-input')) {
        const stu = state.students.find((s) => s.id === e.target.dataset.stuId);
        if (stu) {
          stu.rate = e.target.value === '' ? '' : Math.max(0, Math.round(Number(e.target.value) || 0));
          saveState();
          renderAll();
        }
      } else if (e.target.classList.contains('paid-checkbox')) {
        const adj = getMonthAdj(ymKey(state.activeYear, state.activeMonth));
        adj.paidMap[e.target.dataset.sumKey] = e.target.checked;
        saveState();
        renderAll();
      }
    });

    document.getElementById('btnCopySummaryText').addEventListener('click', () => {
      const report = window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth);
      const lines = [`【${report.year}年${report.month}月 每月家教薪資收入總表】`, '──────────────'];
      report.summaryRows.forEach((r, idx) => {
        lines.push(`${idx + 1}. ${r.label}（${r.sessionCount}堂）：NT$ ${formatMoney(r.totalAmount)}`);
      });
      lines.push('──────────────');
      lines.push(`當月合計：NT$ ${formatMoney(report.grandTotal)}`);
      copyTextToClipboard(lines.join('\n'), '已複製當月家教薪資總表文字！');
    });

    // 右欄明細下拉切換與按鈕
    document.getElementById('activeCardSelect').addEventListener('change', (e) => {
      state.selectedCardId = e.target.value;
      saveState();
      renderOverviewSplit(window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth));
    });

    document.getElementById('btnAddManualSession').addEventListener('click', () => {
      const report = window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth);
      const card = report.detailCards.find((c) => c.cardId === state.selectedCardId);
      if (!card) return;
      const adj = getMonthAdj(report.ym);
      if (!adj.manualSessions[card.cardId]) adj.manualSessions[card.cardId] = [];
      const firstStu = card.students[0];
      const defaultDate = `${report.year}-${format2(report.month)}-01`;
      const inputDate = window.prompt('請輸入補登課堂日期 (YYYY-MM-DD)：', defaultDate);
      if (!inputDate) return;
      adj.manualSessions[card.cardId].push({
        id: uid('man'),
        dateStr: inputDate.trim(),
        studentName: firstStu.name,
        durationMin: 60,
        amount: Number(firstStu.rate) || 0,
        note: '手動補登'
      });
      saveState();
      renderAll();
    });

    document.getElementById('btnAddExtraRow').addEventListener('click', () => {
      const report = window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth);
      const card = report.detailCards.find((c) => c.cardId === state.selectedCardId);
      if (!card) return;
      const adj = getMonthAdj(report.ym);
      const current = adj.cardExtras[card.cardId] && adj.cardExtras[card.cardId].length > 0
        ? adj.cardExtras[card.cardId]
        : [{ id: 'default_extra', label: '書費/其他費用', amount: '', note: '' }];
      current.push({ id: uid('ex'), label: '書費/其他費用', amount: '', note: '' });
      adj.cardExtras[card.cardId] = current;
      saveState();
      renderAll();
    });

    document.getElementById('btnCopyCardText').addEventListener('click', () => {
      const report = window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth);
      const card = report.detailCards.find((c) => c.cardId === state.selectedCardId);
      if (!card) return;
      copyTextToClipboard(formatCardAsPlainText(card, report.year, report.month), `已複製「${card.studentLabel}」的費用明細文字，可直接貼上 LINE！`);
    });

    // 委派處理所有明細表內（Overview 右欄 + Details 網格）的行內編輯與按鈕
    const handleDetailChange = (e) => {
      const t = e.target;
      const ym = ymKey(state.activeYear, state.activeMonth);
      const adj = getMonthAdj(ym);

      if (t.classList.contains('stu-base-rate-input')) {
        const stu = state.students.find((s) => s.id === t.dataset.stuId);
        if (stu) {
          stu.rate = t.value === '' ? '' : Math.max(0, Math.round(Number(t.value) || 0));
          saveState();
          renderAll();
        }
        return;
      }

      if (t.classList.contains('stu-mode-select')) {
        const stu = state.students.find((s) => s.id === t.dataset.stuId);
        if (stu) {
          stu.pricingMode = t.value;
          saveState();
          renderAll();
        }
        return;
      }

      if (t.classList.contains('amount-input')) {
        const sKey = t.dataset.sessionKey;
        const cId = t.dataset.cardId;
        if (t.dataset.isManual === '1') {
          const item = (adj.manualSessions[cId] || []).find((m) => m.id === sKey);
          if (item) item.amount = Math.round(Number(t.value) || 0);
        } else {
          if (!adj.sessionOverrides[sKey]) adj.sessionOverrides[sKey] = {};
          adj.sessionOverrides[sKey].customAmount = Math.round(Number(t.value) || 0);
        }
        saveState();
        renderAll();
        return;
      }

      if (t.classList.contains('note-input')) {
        const sKey = t.dataset.sessionKey;
        const cId = t.dataset.cardId;
        if (t.dataset.isManual === '1') {
          const item = (adj.manualSessions[cId] || []).find((m) => m.id === sKey);
          if (item) item.note = t.value;
        } else {
          if (!adj.sessionOverrides[sKey]) adj.sessionOverrides[sKey] = {};
          adj.sessionOverrides[sKey].note = t.value;
        }
        saveState();
        renderAll();
        return;
      }

      if (t.classList.contains('extra-label-input') || t.classList.contains('extra-amount-input') || t.classList.contains('extra-note-input')) {
        const cId = t.dataset.cardId;
        const idx = Number(t.dataset.extraIdx);
        if (!adj.cardExtras[cId] || adj.cardExtras[cId].length === 0) {
          adj.cardExtras[cId] = [{ id: 'default_extra', label: '書費/其他費用', amount: '', note: '' }];
        }
        const ex = adj.cardExtras[cId][idx];
        if (ex) {
          if (t.classList.contains('extra-label-input')) ex.label = t.value;
          if (t.classList.contains('extra-amount-input')) ex.amount = t.value === '' ? '' : Math.round(Number(t.value) || 0);
          if (t.classList.contains('extra-note-input')) ex.note = t.value;
          saveState();
          renderAll();
        }
      }
    };

    const handleDetailClick = (e) => {
      const ym = ymKey(state.activeYear, state.activeMonth);
      const adj = getMonthAdj(ym);

      const editModalBtn = e.target.closest('.btn-edit-stu-modal');
      if (editModalBtn) {
        openStudentModal(editModalBtn.dataset.stuId);
        return;
      }

      const resetBtn = e.target.closest('.btn-reset-override');
      if (resetBtn) {
        const sKey = resetBtn.dataset.sessionKey;
        if (adj.sessionOverrides[sKey]) {
          delete adj.sessionOverrides[sKey].customAmount;
          saveState();
          renderAll();
        }
        return;
      }

      const exBtn = e.target.closest('.btn-exclude-session');
      if (exBtn) {
        const sKey = exBtn.dataset.sessionKey;
        const cId = exBtn.dataset.cardId;
        if (exBtn.dataset.isManual === '1') {
          adj.manualSessions[cId] = (adj.manualSessions[cId] || []).filter((m) => m.id !== sKey);
        } else {
          if (!adj.sessionOverrides[sKey]) adj.sessionOverrides[sKey] = {};
          adj.sessionOverrides[sKey].excluded = true;
        }
        saveState();
        renderAll();
        return;
      }

      const restoreBtn = e.target.closest('.chip-restore-session');
      if (restoreBtn) {
        const sKey = restoreBtn.dataset.sessionKey;
        if (adj.sessionOverrides[sKey]) {
          adj.sessionOverrides[sKey].excluded = false;
          saveState();
          renderAll();
        }
        return;
      }

      const rmExtraBtn = e.target.closest('.btn-remove-extra');
      if (rmExtraBtn) {
        const cId = rmExtraBtn.dataset.cardId;
        const idx = Number(rmExtraBtn.dataset.extraIdx);
        if (Array.isArray(adj.cardExtras[cId])) {
          adj.cardExtras[cId].splice(idx, 1);
          saveState();
          renderAll();
        }
        return;
      }

      const gridCopyBtn = e.target.closest('.btn-grid-copy');
      if (gridCopyBtn) {
        const report = window.__latestReport || buildMonthlyReport(state.activeYear, state.activeMonth);
        const card = report.detailCards.find((c) => c.cardId === gridCopyBtn.dataset.cardId);
        if (card) {
          copyTextToClipboard(formatCardAsPlainText(card, report.year, report.month), `已複製「${card.studentLabel}」的明細文字！`);
        }
      }
    };

    document.getElementById('activeDetailContainer').addEventListener('change', handleDetailChange);
    document.getElementById('activeDetailContainer').addEventListener('click', handleDetailClick);
    document.getElementById('viewDetails').addEventListener('change', handleDetailChange);
    document.getElementById('viewDetails').addEventListener('click', handleDetailClick);

    // 學生管理視圖 (viewStudents) 與 Modal
    document.getElementById('btnAddStudentQuick').addEventListener('click', () => openStudentModal(''));
    document.getElementById('btnAddStudentTop').addEventListener('click', () => openStudentModal(''));

    document.getElementById('studentsConfigBody').addEventListener('change', (e) => {
      const t = e.target;
      const stu = state.students.find((s) => s.id === t.dataset.stuId);
      if (!stu) return;
      if (t.classList.contains('cfg-mode-select')) stu.pricingMode = t.value;
      else if (t.classList.contains('cfg-rate-input')) stu.rate = t.value === '' ? '' : Math.max(0, Math.round(Number(t.value) || 0));
      else if (t.classList.contains('cfg-group-input')) stu.groupName = t.value.trim();
      else if (t.classList.contains('cfg-gmode-select')) {
        stu.groupDetailMode = t.value;
        // 同步同一家庭群組的呈現模式，避免同群組設定不一致
        if (stu.groupName) {
          state.students.forEach((other) => {
            if (other.groupName === stu.groupName) other.groupDetailMode = t.value;
          });
        }
      }
      saveState();
      renderAll();
    });

    document.getElementById('studentsConfigBody').addEventListener('click', (e) => {
      const editBtn = e.target.closest('.btn-edit-stu-modal');
      if (editBtn) {
        openStudentModal(editBtn.dataset.stuId);
        return;
      }
      const delBtn = e.target.closest('.btn-delete-stu');
      if (delBtn) {
        const stu = state.students.find((s) => s.id === delBtn.dataset.stuId);
        if (stu && window.confirm(`確定要刪除學生「${stu.name}」的計費規則嗎？`)) {
          state.students = state.students.filter((s) => s.id !== stu.id);
          saveState();
          renderAll();
        }
      }
    });

    document.getElementById('ignoredChips').addEventListener('click', (e) => {
      const btn = e.target.closest('.btn-remove-ignored');
      if (!btn) return;
      state.ignoredEventTitles = state.ignoredEventTitles.filter((k) => k !== btn.dataset.kw);
      saveState();
      renderAll();
    });

    document.getElementById('studentForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const id = document.getElementById('stuFormId').value;
      const name = document.getElementById('stuFormName').value.trim();
      const courseName = document.getElementById('stuFormCourse').value.trim();
      const keywords = document.getElementById('stuFormKeywords').value
        .split(/[,，、]/)
        .map((k) => k.trim())
        .filter(Boolean);
      const pricingMode = document.getElementById('stuFormPricingMode').value;
      const rateVal = document.getElementById('stuFormRate').value;
      const groupName = document.getElementById('stuFormGroup').value.trim();
      const summaryLabel = document.getElementById('stuFormSummaryLabel').value.trim();
      const groupDetailMode = document.getElementById('stuFormGroupMode').value;

      if (!name || keywords.length === 0) {
        showToast('請填寫學生姓名與至少一個比對關鍵字', 'error');
        return;
      }

      const payload = {
        id: id || uid('stu'),
        name,
        summaryLabel,
        courseName,
        keywords,
        pricingMode,
        rate: rateVal === '' ? '' : Math.max(0, Math.round(Number(rateVal) || 0)),
        groupName,
        groupDetailMode
      };

      if (id) {
        const idx = state.students.findIndex((s) => s.id === id);
        if (idx >= 0) state.students[idx] = payload;
      } else {
        state.students.push(payload);
        state.selectedCardId = groupName && groupDetailMode === 'merged_both' ? `grp_${groupName}` : `stu_${payload.id}`;
      }

      if (groupName) {
        state.students.forEach((other) => {
          if (other.groupName === groupName) other.groupDetailMode = groupDetailMode;
        });
      }

      saveState();
      closeModal('studentModal');
      renderAll();
      showToast(`已儲存學生「${name}」設定`, 'success');
    });

    // 備份與還原 Modal
    document.getElementById('btnBackupModal').addEventListener('click', () => openModal('backupModal'));

    document.getElementById('btnDownloadBackup').addEventListener('click', () => {
      const backupStr = JSON.stringify(state, null, 2);
      const blob = new Blob([backupStr], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `家教結算工具備份_${ymCompact(state.activeYear, state.activeMonth)}.json`;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        a.remove();
        URL.revokeObjectURL(url);
      }, 400);
      showToast('已下載備份檔案 (.json)', 'success');
    });

    document.getElementById('inputRestoreBackup').addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      try {
        const parsed = JSON.parse(await file.text());
        if (!Array.isArray(parsed.students)) {
          throw new Error('備份檔案格式不正確');
        }
        state = Object.assign(getDefaultState(), parsed);
        saveState();
        closeModal('backupModal');
        renderAll();
        showToast('已成功還原所有學生名單與帳務設定！', 'success');
      } catch (err) {
        showToast(`還原失敗：${err.message}`, 'error');
      } finally {
        e.target.value = '';
      }
    });

    document.getElementById('btnResetAllData').addEventListener('click', () => {
      if (!window.confirm('確定要清空瀏覽器內儲存的所有學生設定與行程快取嗎？（建議先匯出備份）')) return;
      window.GoogleCalendarSync.clearToken();
      localStorage.removeItem(CFG.STORAGE_KEY);
      state = getDefaultState();
      closeModal('backupModal');
      renderAll();
      showToast('已重設所有本機資料', 'info');
    });
  }

  function openStudentModal(stuId) {
    const stu = state.students.find((s) => s.id === stuId);
    document.getElementById('studentModalTitle').textContent = stu ? `✏️ 編輯學生：${stu.name}` : '👩‍🏫 新增學生計費規則';
    document.getElementById('stuFormId').value = stu ? stu.id : '';
    document.getElementById('stuFormName').value = stu ? stu.name : '';
    document.getElementById('stuFormCourse').value = stu ? (stu.courseName || '') : '';
    document.getElementById('stuFormKeywords').value = stu ? (stu.keywords || []).join(', ') : '';
    document.getElementById('stuFormPricingMode').value = stu ? (stu.pricingMode || 'per_session') : 'per_session';
    document.getElementById('stuFormRate').value = stu && stu.rate !== '' && stu.rate != null ? stu.rate : '';
    document.getElementById('stuFormGroup').value = stu ? (stu.groupName || '') : '';
    document.getElementById('stuFormSummaryLabel').value = stu ? (stu.summaryLabel || '') : '';
    document.getElementById('stuFormGroupMode').value = stu ? (stu.groupDetailMode || 'separate_detail_merged_summary') : 'separate_detail_merged_summary';
    openModal('studentModal');
    setTimeout(() => document.getElementById('stuFormName').focus(), 50);
  }

  // 當姓名輸入框自動帶入關鍵字（僅新增且關鍵字為空時貼心輔助）
  document.addEventListener('DOMContentLoaded', () => {
    const nameInput = document.getElementById('stuFormName');
    const kwInput = document.getElementById('stuFormKeywords');
    nameInput.addEventListener('blur', () => {
      if (!kwInput.value.trim() && nameInput.value.trim()) {
        kwInput.value = nameInput.value.trim();
      }
    });

    bindEvents();
    renderAll();
  });
})();
