/**
 * Google Calendar OAuth 2.0 一鍵登入與行程同步模組
 * 使用官方 Google Identity Services (GIS) Token Model (純前端、無需後端伺服器)
 * Scope: https://www.googleapis.com/auth/calendar.readonly (唯讀，絕不修改使用者日曆)
 */
(function () {
  'use strict';

  const SESSION_TOKEN_KEY = 'gcal_tutoring_oauth_token_v1';
  const GIS_SRC = 'https://accounts.google.com/gsi/client';

  let gisLoadPromise = null;

  function ensureGisLoaded() {
    if (window.google && window.google.accounts && window.google.accounts.oauth2) {
      return Promise.resolve();
    }
    if (gisLoadPromise) return gisLoadPromise;

    gisLoadPromise = new Promise((resolve, reject) => {
      const existing = document.querySelector(`script[src="${GIS_SRC}"]`);
      if (existing) {
        existing.addEventListener('load', () => resolve());
        existing.addEventListener('error', () => reject(new Error('無法載入 Google 登入元件，請檢查網路連線或廣告阻擋器。')));
        return;
      }
      const script = document.createElement('script');
      script.src = GIS_SRC;
      script.async = true;
      script.defer = true;
      script.onload = () => resolve();
      script.onerror = () => {
        gisLoadPromise = null;
        reject(new Error('無法載入 Google 登入元件 (accounts.google.com)，請確認網路連線正常。'));
      };
      document.head.appendChild(script);
    });
    return gisLoadPromise;
  }

  function getSavedToken(clientId) {
    try {
      const raw = sessionStorage.getItem(SESSION_TOKEN_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed.accessToken || parsed.clientId !== clientId) return null;
      // 預留 60 秒緩衝
      if (Date.now() >= (parsed.expiresAt - 60000)) {
        sessionStorage.removeItem(SESSION_TOKEN_KEY);
        return null;
      }
      return parsed;
    } catch (_) {
      return null;
    }
  }

  function saveToken(clientId, accessToken, expiresInSec, userEmail) {
    const record = {
      clientId,
      accessToken,
      expiresAt: Date.now() + (Number(expiresInSec) || 3599) * 1000,
      userEmail: userEmail || ''
    };
    try {
      sessionStorage.setItem(SESSION_TOKEN_KEY, JSON.stringify(record));
    } catch (_) {}
    return record;
  }

  function clearToken() {
    try {
      sessionStorage.removeItem(SESSION_TOKEN_KEY);
    } catch (_) {}
  }

  /**
   * 觸發 Google 帳號一鍵授權視窗，取得唯讀 Access Token
   */
  async function signInWithGoogle(clientId, forceAccountSelect = false) {
    const trimmedId = String(clientId || '').trim();
    if (!trimmedId) {
      throw new Error('尚未設定 Google OAuth Client ID，請先在「Google 同步設定」填入 Client ID。');
    }
    await ensureGisLoaded();

    return new Promise((resolve, reject) => {
      let settled = false;
      const tokenClient = window.google.accounts.oauth2.initTokenClient({
        client_id: trimmedId,
        scope: window.TUTORING_CALC_CONFIG.CALENDAR_SCOPE,
        callback: async (resp) => {
          if (settled) return;
          settled = true;
          if (resp.error) {
            reject(new Error(`Google 授權失敗：${resp.error_description || resp.error}`));
            return;
          }
          const rec = saveToken(trimmedId, resp.access_token, resp.expires_in, '');
          resolve(rec);
        },
        error_callback: (err) => {
          if (settled) return;
          settled = true;
          const msg = err && err.type === 'popup_closed'
            ? '已關閉 Google 登入視窗'
            : `Google 登入視窗無法開啟 (${(err && err.type) || 'unknown'})，請確認瀏覽器未封鎖彈出視窗。`;
          reject(new Error(msg));
        }
      });

      tokenClient.requestAccessToken({
        prompt: forceAccountSelect ? 'select_account' : ''
      });
    });
  }

  async function gcalFetchJson(url, accessToken) {
    const resp = await fetch(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: 'application/json'
      }
    });
    if (resp.status === 401 || resp.status === 403) {
      let detail = '';
      try {
        const errJson = await resp.json();
        detail = (errJson.error && errJson.error.message) || '';
      } catch (_) {}
      if (resp.status === 401) clearToken();
      throw new Error(
        resp.status === 401
          ? 'Google 登入授權已過期，請重新點擊「連結 Google 日曆」登入。'
          : `Google Calendar API 拒絕存取 (403)：請確認該專案已啟用 Google Calendar API。${detail ? ' (' + detail + ')' : ''}`
      );
    }
    if (!resp.ok) {
      throw new Error(`讀取 Google 日曆失敗 (HTTP ${resp.status})`);
    }
    return resp.json();
  }

  /**
   * 取得使用者帳號下所有子日曆清單（例如「個人家教」、主日曆等）
   */
  async function fetchCalendarList(accessToken) {
    const url = 'https://www.googleapis.com/calendar/v3/users/me/calendarList?minAccessRole=reader&maxResults=250';
    const data = await gcalFetchJson(url, accessToken);
    const items = Array.isArray(data.items) ? data.items : [];

    // 智慧排序：名稱含「家教 / 課 / 教學 / 學生」優先排最上面，其次為主日曆，節假日排最後
    const scoreCal = (c) => {
      const name = String(c.summary || '');
      if (/(家教|課|教學|音樂|鋼琴|提琴|學生|tutor|lesson)/i.test(name)) return 0;
      if (c.primary) return 1;
      if (String(c.id || '').includes('#holiday@') || String(c.id || '').includes('#contacts@')) return 9;
      return 3;
    };

    return items
      .filter((c) => !c.deleted)
      .map((c) => ({
        id: c.id,
        summary: c.summaryOverride || c.summary || c.id,
        primary: Boolean(c.primary),
        backgroundColor: c.backgroundColor || '#6366f1',
        accessRole: c.accessRole || 'reader'
      }))
      .sort((a, b) => scoreCal(a) - scoreCal(b) || a.summary.localeCompare(b.summary, 'zh-Hant'));
  }

  function format2(n) {
    return String(n).padStart(2, '0');
  }

  /**
   * 將單筆 Google Calendar API Event 正規化為本地時間結構
   */
  function normalizeApiEvent(ev, calendarId, calendarName) {
    if (!ev || ev.status === 'cancelled') return null;
    const title = String(ev.summary || '').trim();
    if (!title) return null;

    // 若使用者自己在參加者名單中且已明確按「拒絕 (declined)」，則跳過
    if (Array.isArray(ev.attendees)) {
      const selfAtt = ev.attendees.find((a) => a && a.self);
      if (selfAtt && selfAtt.responseStatus === 'declined') return null;
    }

    const isAllDay = Boolean(ev.start && ev.start.date && !ev.start.dateTime);
    let dateStr = '';
    let year = 0;
    let month = 0;
    let day = 0;
    let weekday = 0;
    let durationMin = 60;
    let timeLabel = '全天';
    let sortTs = 0;

    if (isAllDay) {
      // ev.start.date 格式為 YYYY-MM-DD
      dateStr = ev.start.date;
      const parts = dateStr.split('-').map(Number);
      year = parts[0];
      month = parts[1];
      day = parts[2];
      const d = new Date(year, month - 1, day);
      weekday = d.getDay();
      sortTs = d.getTime();
      durationMin = 60;
    } else if (ev.start && ev.start.dateTime) {
      const startDt = new Date(ev.start.dateTime);
      const endDt = (ev.end && ev.end.dateTime) ? new Date(ev.end.dateTime) : new Date(startDt.getTime() + 3600000);
      year = startDt.getFullYear();
      month = startDt.getMonth() + 1;
      day = startDt.getDate();
      weekday = startDt.getDay();
      dateStr = `${year}-${format2(month)}-${format2(day)}`;
      sortTs = startDt.getTime();

      const diffMin = Math.round((endDt.getTime() - startDt.getTime()) / 60000);
      durationMin = diffMin > 0 ? diffMin : 60;

      const sh = format2(startDt.getHours());
      const sm = format2(startDt.getMinutes());
      const eh = format2(endDt.getHours());
      const em = format2(endDt.getMinutes());
      timeLabel = `${sh}:${sm}–${eh}:${em}`;
    } else {
      return null;
    }

    return {
      id: `${calendarId}::${ev.id}`,
      rawEventId: ev.id,
      calendarId,
      calendarName: calendarName || '',
      title,
      dateStr,
      year,
      month,
      day,
      weekday,
      timeLabel,
      durationMin,
      isAllDay,
      sortTs
    };
  }

  /**
   * 抓取指定年、月、多個子日曆的所有展開後行程 (singleEvents=true)
   */
  async function fetchMonthEvents(accessToken, calendars, year, month) {
    if (!Array.isArray(calendars) || calendars.length === 0) {
      throw new Error('請至少勾選一個要讀取的 Google 子日曆（例如：個人家教）。');
    }

    // 本地時區當月 1 日 00:00:00 至次月 1 日 00:00:00
    const startLocal = new Date(year, month - 1, 1, 0, 0, 0, 0);
    const endLocal = new Date(year, month, 1, 0, 0, 0, 0);
    const timeMin = startLocal.toISOString();
    const timeMax = endLocal.toISOString();

    const allEvents = [];
    for (const cal of calendars) {
      const calId = typeof cal === 'string' ? cal : cal.id;
      const calName = typeof cal === 'string' ? cal : (cal.summary || cal.id);
      let pageToken = '';

      do {
        const params = new URLSearchParams({
          timeMin,
          timeMax,
          singleEvents: 'true',
          orderBy: 'startTime',
          maxResults: '2500'
        });
        if (pageToken) params.set('pageToken', pageToken);

        const url = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calId)}/events?${params.toString()}`;
        const data = await gcalFetchJson(url, accessToken);
        const items = Array.isArray(data.items) ? data.items : [];

        for (const ev of items) {
          const norm = normalizeApiEvent(ev, calId, calName);
          // 確保跨日或時區邊界只計入當月開始的課堂
          if (norm && norm.year === year && norm.month === month) {
            allEvents.push(norm);
          }
        }
        pageToken = data.nextPageToken || '';
      } while (pageToken);
    }

    allEvents.sort((a, b) => a.sortTs - b.sortTs || a.title.localeCompare(b.title, 'zh-Hant'));
    return allEvents;
  }

  window.GoogleCalendarSync = {
    getSavedToken,
    clearToken,
    signInWithGoogle,
    fetchCalendarList,
    fetchMonthEvents
  };
})();
